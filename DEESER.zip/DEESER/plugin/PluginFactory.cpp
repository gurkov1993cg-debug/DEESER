#include "DeEsserController.h"
#include "DeEsserIDs.h"
#include "DeEsserProcessor.h"
#include "Version.h"

#include "pluginterfaces/vst/ivstaudioprocessor.h"
#include "pluginterfaces/vst/ivsteditcontroller.h"
#include "pluginterfaces/vst/vsttypes.h"
#include "public.sdk/source/main/pluginfactory_constexpr.h"

BEGIN_FACTORY_DEF(DEESER_VENDOR,
                  "https://github.com/gurkov1993cg-debug/DEESER",
                  "",
                  2)

DEF_CLASS(Steinberg::Vst::DeEsserProcessorUID,
          Steinberg::PClassInfo::kManyInstances,
          kVstAudioEffectClass,
          DEESER_NAME,
          Steinberg::Vst::kDistributable,
          "Fx|Dynamics",
          DEESER_VERSION_STR,
          kVstVersionString,
          Steinberg::Vst::DeEsserProcessor::createInstance,
          nullptr)

DEF_CLASS(Steinberg::Vst::DeEsserControllerUID,
          Steinberg::PClassInfo::kManyInstances,
          kVstComponentControllerClass,
          DEESER_NAME " Controller",
          0,
          "",
          DEESER_VERSION_STR,
          kVstVersionString,
          Steinberg::Vst::DeEsserController::createInstance,
          nullptr)

END_FACTORY

#pragma once
#define DEESER_VERSION_STR "1.1.0"
#define DEESER_NAME "Silveton De-Esser"
#define DEESER_VENDOR "Silveton"

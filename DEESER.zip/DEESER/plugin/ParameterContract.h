#pragma once

#include <algorithm>
#include <array>
#include <cstdint>
#include <cmath>
#include <cstddef>

namespace deeser::param {

enum ID : std::uint32_t {
    Sensitivity = 100,
    Amount = 101,
    FocusHz = 102,
    MaxReductionDb = 103,
    AutoMode = 104,
    Listen = 105,
    StereoLink = 106,
    Bypass = 107,
    Musicality = 108,
    AirProtect = 109,

    MeterInputDb = 200,
    MeterOutputDb = 201,
    MeterGainReductionDb = 202,
    MeterDetector = 203,
    MeterDetectedFrequencyHz = 204,

    // Real detector-bank spectrum used by the GUI analyzer. These are read-only
    // VST3 parameters fed from the actual DSP detector bands, never decorative data.
    MeterAnalyzer3600Db = 205,
    MeterAnalyzer4400Db = 206,
    MeterAnalyzer5400Db = 207,
    MeterAnalyzer6600Db = 208,
    MeterAnalyzer8000Db = 209,
    MeterAnalyzer9800Db = 210,
    MeterAnalyzer11800Db = 211,

    // Lightweight FFT spectrum transport. Read-only, not part of saved state.
    SpectrumMeterBase = 300,
    SpectrumMeterLast = 363
};

inline constexpr std::array<ID, 7> analyzerMeterIds{{
    MeterAnalyzer3600Db,
    MeterAnalyzer4400Db,
    MeterAnalyzer5400Db,
    MeterAnalyzer6600Db,
    MeterAnalyzer8000Db,
    MeterAnalyzer9800Db,
    MeterAnalyzer11800Db
}};

inline constexpr std::array<double, 7> analyzerCenterHz{{
    3600.0, 4400.0, 5400.0, 6600.0, 8000.0, 9800.0, 11800.0
}};

inline constexpr std::size_t spectrumMeterCount = 64;
inline constexpr double spectrumMinHz = 40.0;
inline constexpr double spectrumMaxHz = 20000.0;
inline constexpr double spectrumMinDb = -90.0;
inline constexpr double spectrumMaxDb = 6.0;

inline constexpr ID spectrumMeterId(std::size_t index) noexcept {
    return static_cast<ID>(static_cast<std::uint32_t>(SpectrumMeterBase) + static_cast<std::uint32_t>(index));
}

inline constexpr bool isSpectrumMeter(ID id) noexcept {
    const auto raw = static_cast<std::uint32_t>(id);
    return raw >= static_cast<std::uint32_t>(SpectrumMeterBase) &&
           raw <= static_cast<std::uint32_t>(SpectrumMeterLast);
}

inline double spectrumCenterHz(std::size_t index) noexcept {
    if (spectrumMeterCount <= 1) return spectrumMinHz;
    const double n = static_cast<double>(std::min(index, spectrumMeterCount - 1)) /
                     static_cast<double>(spectrumMeterCount - 1);
    return spectrumMinHz * std::pow(spectrumMaxHz / spectrumMinHz, n);
}

struct Spec {
    ID id;
    double minPlain;
    double maxPlain;
    double defaultPlain;
    bool readOnly;
};

inline constexpr std::array<Spec, 22> specs{{
    {Sensitivity, 0.0, 100.0, 60.0, false},
    {Amount, 0.0, 100.0, 75.0, false},
    {FocusHz, 3200.0, 12000.0, 6500.0, false},
    {MaxReductionDb, 1.0, 18.0, 8.0, false},
    {AutoMode, 0.0, 1.0, 1.0, false},
    {Listen, 0.0, 1.0, 0.0, false},
    {StereoLink, 0.0, 1.0, 1.0, false},
    {Bypass, 0.0, 1.0, 0.0, false},
    {Musicality, 0.0, 100.0, 78.0, false},
    {AirProtect, 0.0, 100.0, 70.0, false},
    {MeterInputDb, -60.0, 6.0, -60.0, true},
    {MeterOutputDb, -60.0, 6.0, -60.0, true},
    {MeterGainReductionDb, 0.0, 18.0, 0.0, true},
    {MeterDetector, 0.0, 1.0, 0.0, true},
    {MeterDetectedFrequencyHz, 0.0, 12000.0, 0.0, true},
    {MeterAnalyzer3600Db, -72.0, 6.0, -72.0, true},
    {MeterAnalyzer4400Db, -72.0, 6.0, -72.0, true},
    {MeterAnalyzer5400Db, -72.0, 6.0, -72.0, true},
    {MeterAnalyzer6600Db, -72.0, 6.0, -72.0, true},
    {MeterAnalyzer8000Db, -72.0, 6.0, -72.0, true},
    {MeterAnalyzer9800Db, -72.0, 6.0, -72.0, true},
    {MeterAnalyzer11800Db, -72.0, 6.0, -72.0, true}
}};

inline constexpr const Spec* find(ID id) noexcept {
    for (const auto& s : specs) if (s.id == id) return &s;
    return nullptr;
}

inline double toNormalized(ID id, double plain) noexcept {
    if (isSpectrumMeter(id)) {
        plain = std::max(spectrumMinDb, std::min(plain, spectrumMaxDb));
        return (plain - spectrumMinDb) / (spectrumMaxDb - spectrumMinDb);
    }
    const auto* s = find(id);
    if (!s || s->maxPlain <= s->minPlain) return 0.0;
    plain = std::max(s->minPlain, std::min(plain, s->maxPlain));
    return (plain - s->minPlain) / (s->maxPlain - s->minPlain);
}

inline double toPlain(ID id, double normalized) noexcept {
    if (isSpectrumMeter(id)) {
        normalized = std::max(0.0, std::min(normalized, 1.0));
        return spectrumMinDb + normalized * (spectrumMaxDb - spectrumMinDb);
    }
    const auto* s = find(id);
    if (!s) return 0.0;
    normalized = std::max(0.0, std::min(normalized, 1.0));
    return s->minPlain + normalized * (s->maxPlain - s->minPlain);
}

inline double defaultNormalized(ID id) noexcept {
    if (isSpectrumMeter(id)) return 0.0;
    const auto* s = find(id);
    return s ? toNormalized(id, s->defaultPlain) : 0.0;
}

inline bool isBoolean(ID id) noexcept {
    return id == AutoMode || id == Listen || id == StereoLink || id == Bypass;
}

inline bool isMeter(ID id) noexcept {
    if (isSpectrumMeter(id)) return true;
    const auto* s = find(id);
    return s && s->readOnly;
}

} // namespace deeser::param

#pragma once

#include <algorithm>
#include <array>
#include <cstdint>

namespace deeser::param {

enum ID : std::uint32_t {
    Sensitivity = 100,
    Amount = 101,
    FocusHz = 102,
    MaxReductionDb = 103,
    AutoMode = 104,
    Listen = 105,
    StereoLink = 106,
    Bypass = 107,
    Musicality = 108,
    AirProtect = 109,

    MeterInputDb = 200,
    MeterOutputDb = 201,
    MeterGainReductionDb = 202,
    MeterDetector = 203,
    MeterDetectedFrequencyHz = 204
};

struct Spec {
    ID id;
    double minPlain;
    double maxPlain;
    double defaultPlain;
    bool readOnly;
};

inline constexpr std::array<Spec, 15> specs{{
    {Sensitivity, 0.0, 100.0, 60.0, false},
    {Amount, 0.0, 100.0, 75.0, false},
    {FocusHz, 3200.0, 12000.0, 6500.0, false},
    {MaxReductionDb, 1.0, 18.0, 8.0, false},
    {AutoMode, 0.0, 1.0, 1.0, false},
    {Listen, 0.0, 1.0, 0.0, false},
    {StereoLink, 0.0, 1.0, 1.0, false},
    {Bypass, 0.0, 1.0, 0.0, false},
    {Musicality, 0.0, 100.0, 78.0, false},
    {AirProtect, 0.0, 100.0, 70.0, false},
    {MeterInputDb, -60.0, 6.0, -60.0, true},
    {MeterOutputDb, -60.0, 6.0, -60.0, true},
    {MeterGainReductionDb, 0.0, 18.0, 0.0, true},
    {MeterDetector, 0.0, 1.0, 0.0, true},
    {MeterDetectedFrequencyHz, 0.0, 12000.0, 0.0, true}
}};

inline constexpr const Spec* find(ID id) noexcept {
    for (const auto& s : specs) if (s.id == id) return &s;
    return nullptr;
}

inline double toNormalized(ID id, double plain) noexcept {
    const auto* s = find(id);
    if (!s || s->maxPlain <= s->minPlain) return 0.0;
    plain = std::max(s->minPlain, std::min(plain, s->maxPlain));
    return (plain - s->minPlain) / (s->maxPlain - s->minPlain);
}

inline double toPlain(ID id, double normalized) noexcept {
    const auto* s = find(id);
    if (!s) return 0.0;
    normalized = std::max(0.0, std::min(normalized, 1.0));
    return s->minPlain + normalized * (s->maxPlain - s->minPlain);
}

inline double defaultNormalized(ID id) noexcept {
    const auto* s = find(id);
    return s ? toNormalized(id, s->defaultPlain) : 0.0;
}

inline bool isBoolean(ID id) noexcept {
    return id == AutoMode || id == Listen || id == StereoLink || id == Bypass;
}

inline bool isMeter(ID id) noexcept {
    const auto* s = find(id);
    return s && s->readOnly;
}

} // namespace deeser::param

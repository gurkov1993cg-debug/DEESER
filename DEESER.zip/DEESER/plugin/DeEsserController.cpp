#include "DeEsserController.h"
#include "ParameterContract.h"
#include "StateContract.h"
#if SMTG_OS_MACOS
#include "NativeEditor.h"
#endif

#include "base/source/fstreamer.h"
#include "pluginterfaces/base/ibstream.h"
#include "public.sdk/source/vst/vstparameters.h"

#include <cstring>

namespace Steinberg::Vst {
namespace {
using deeser::param::ID;

void addRange(ParameterContainer& params, const TChar* title, const TChar* units, ID id,
              int32 flags = ParameterInfo::kCanAutomate) {
    const auto* s = deeser::param::find(id);
    params.addParameter(new RangeParameter(title, static_cast<ParamID>(id), units,
                                           s->minPlain, s->maxPlain, s->defaultPlain, 0, flags));
}

void addBool(ParameterContainer& params, const TChar* title, ID id, int32 flags) {
    params.addParameter(title, nullptr, 1, deeser::param::defaultNormalized(id), flags, static_cast<ParamID>(id));
}
}

tresult PLUGIN_API DeEsserController::initialize(FUnknown* context) {
    const auto r = EditController::initialize(context);
    if (r != kResultTrue) return r;

    addRange(parameters, STR16("Sensitivity"), STR16("%"), ID::Sensitivity);
    addRange(parameters, STR16("Amount"), STR16("%"), ID::Amount);
    addRange(parameters, STR16("Frequency"), STR16("Hz"), ID::FocusHz);
    addRange(parameters, STR16("Max GR"), STR16("dB"), ID::MaxReductionDb);
    addRange(parameters, STR16("Musicality"), STR16("%"), ID::Musicality);
    addRange(parameters, STR16("Air Protect"), STR16("%"), ID::AirProtect);

    addBool(parameters, STR16("Auto"), ID::AutoMode, ParameterInfo::kCanAutomate);
    addBool(parameters, STR16("Listen"), ID::Listen, ParameterInfo::kCanAutomate);
    addBool(parameters, STR16("Stereo Link"), ID::StereoLink, ParameterInfo::kCanAutomate);
    addBool(parameters, STR16("Bypass"), ID::Bypass, ParameterInfo::kCanAutomate | ParameterInfo::kIsBypass);

    addRange(parameters, STR16("Input Meter"), STR16("dB"), ID::MeterInputDb, ParameterInfo::kIsReadOnly);
    addRange(parameters, STR16("Output Meter"), STR16("dB"), ID::MeterOutputDb, ParameterInfo::kIsReadOnly);
    addRange(parameters, STR16("Gain Reduction"), STR16("dB"), ID::MeterGainReductionDb, ParameterInfo::kIsReadOnly);
    addRange(parameters, STR16("Sibilance"), nullptr, ID::MeterDetector, ParameterInfo::kIsReadOnly);
    addRange(parameters, STR16("Detected Frequency"), STR16("Hz"), ID::MeterDetectedFrequencyHz, ParameterInfo::kIsReadOnly);
    return kResultTrue;
}

tresult PLUGIN_API DeEsserController::setComponentState(IBStream* state) {
    if (!state) return kResultFalse;
    IBStreamer s(state, kLittleEndian);
    int32 magic = 0, version = 0;
    if (!s.readInt32(magic) || !s.readInt32(version)) return kResultFalse;
    if (static_cast<std::uint32_t>(magic) != deeser::state::kMagic || version != static_cast<int32>(deeser::state::kVersion)) return kResultFalse;
    std::array<float, deeser::state::kValueCount> v{};
    for (float& x : v) if (!s.readFloat(x)) return kResultFalse;

    setParamNormalized(static_cast<ParamID>(ID::Sensitivity), deeser::param::toNormalized(ID::Sensitivity, v[0] * 100.0));
    setParamNormalized(static_cast<ParamID>(ID::Amount), deeser::param::toNormalized(ID::Amount, v[1] * 100.0));
    setParamNormalized(static_cast<ParamID>(ID::FocusHz), deeser::param::toNormalized(ID::FocusHz, v[2]));
    setParamNormalized(static_cast<ParamID>(ID::MaxReductionDb), deeser::param::toNormalized(ID::MaxReductionDb, v[3]));
    setParamNormalized(static_cast<ParamID>(ID::AutoMode), v[4] >= 0.5f ? 1.0 : 0.0);
    setParamNormalized(static_cast<ParamID>(ID::Listen), v[5] >= 0.5f ? 1.0 : 0.0);
    setParamNormalized(static_cast<ParamID>(ID::StereoLink), v[6] >= 0.5f ? 1.0 : 0.0);
    setParamNormalized(static_cast<ParamID>(ID::Bypass), v[7] >= 0.5f ? 1.0 : 0.0);
    setParamNormalized(static_cast<ParamID>(ID::Musicality), deeser::param::toNormalized(ID::Musicality, v[8] * 100.0));
    setParamNormalized(static_cast<ParamID>(ID::AirProtect), deeser::param::toNormalized(ID::AirProtect, v[9] * 100.0));
    return kResultOk;
}


IPlugView* PLUGIN_API DeEsserController::createView(FIDString name) {
#if SMTG_OS_MACOS
    if (name && std::strcmp(name, ViewType::kEditor) == 0) return new NativeEditor(this);
#else
    (void)name;
#endif
    return nullptr;
}

} // namespace Steinberg::Vst

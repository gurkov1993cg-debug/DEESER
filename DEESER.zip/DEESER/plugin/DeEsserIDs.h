#pragma once
#include "pluginterfaces/base/funknown.h"
namespace Steinberg::Vst {
// Locked IDs: do not change in later builds.
static DECLARE_UID(DeEsserProcessorUID,  0x9840BC5A, 0x964A6DCF, 0x5862754E, 0x8425DD5B);
static DECLARE_UID(DeEsserControllerUID, 0xA4B9C752, 0xBCE1BB5C, 0x27453FBB, 0x4A31C731);
}

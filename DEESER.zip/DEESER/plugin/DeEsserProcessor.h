#pragma once

#include "deeser/DeEsserDSP.h"
#include "public.sdk/source/vst/vstaudioeffect.h"

namespace Steinberg::Vst {

class DeEsserProcessor final : public AudioEffect {
public:
    DeEsserProcessor();
    static FUnknown* createInstance(void*) { return static_cast<IAudioProcessor*>(new DeEsserProcessor()); }

    tresult PLUGIN_API initialize(FUnknown* context) SMTG_OVERRIDE;
    tresult PLUGIN_API terminate() SMTG_OVERRIDE;
    tresult PLUGIN_API setupProcessing(ProcessSetup& setup) SMTG_OVERRIDE;
    tresult PLUGIN_API setActive(TBool state) SMTG_OVERRIDE;
    tresult PLUGIN_API setBusArrangements(SpeakerArrangement* inputs, int32 numIns,
                                          SpeakerArrangement* outputs, int32 numOuts) SMTG_OVERRIDE;
    tresult PLUGIN_API canProcessSampleSize(int32 symbolicSampleSize) SMTG_OVERRIDE;
    tresult PLUGIN_API process(ProcessData& data) SMTG_OVERRIDE;
    tresult PLUGIN_API setState(IBStream* state) SMTG_OVERRIDE;
    tresult PLUGIN_API getState(IBStream* state) SMTG_OVERRIDE;
    uint32 PLUGIN_API getLatencySamples() SMTG_OVERRIDE { return latencySamples_; }
    uint32 PLUGIN_API getTailSamples() SMTG_OVERRIDE { return kNoTail; }

private:
    void applyNormalizedParam(ParamID id, ParamValue normalized) noexcept;
    void pushMeters(IParameterChanges* changes, int32 sampleOffset) noexcept;
    void syncDSP() noexcept;

    deeser::DeEsserDSP dsp_{};
    deeser::Parameters params_{};
    uint32 latencySamples_ = 0;
    int32 configuredChannels_ = 2;
};

} // namespace Steinberg::Vst

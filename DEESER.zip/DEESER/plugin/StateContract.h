#pragma once

#include "deeser/DeEsserDSP.h"
#include <array>
#include <cstdint>

namespace deeser::state {
inline constexpr std::uint32_t kMagic = 0x53445332u; // "SDS2"
inline constexpr std::uint32_t kVersion = 2u;
inline constexpr std::size_t kValueCount = 10u;

inline std::array<float, kValueCount> toValues(const Parameters& p) noexcept {
    return {{p.sensitivity, p.amount, p.focusHz, p.maxReductionDb,
             p.autoMode ? 1.0f : 0.0f, p.listen ? 1.0f : 0.0f,
             p.stereoLink ? 1.0f : 0.0f, p.bypass ? 1.0f : 0.0f,
             p.musicality, p.airProtect}};
}

inline Parameters fromValues(const std::array<float, kValueCount>& v) noexcept {
    Parameters p{};
    p.sensitivity = v[0]; p.amount = v[1]; p.focusHz = v[2]; p.maxReductionDb = v[3];
    p.autoMode = v[4] >= 0.5f; p.listen = v[5] >= 0.5f;
    p.stereoLink = v[6] >= 0.5f; p.bypass = v[7] >= 0.5f;
    p.musicality = v[8]; p.airProtect = v[9];
    return p;
}
} // namespace deeser::state

#include "DeEsserProcessor.h"
#include "DeEsserIDs.h"
#include "ParameterContract.h"
#include "StateContract.h"

#include "base/source/fstreamer.h"
#include "pluginterfaces/base/ibstream.h"
#include "pluginterfaces/vst/ivstparameterchanges.h"
#include "pluginterfaces/vst/vstspeaker.h"

#include <algorithm>
#include <array>
#include <cstring>

namespace Steinberg::Vst {
namespace {
using deeser::param::ID;

void clearOutputs(ProcessData& data) noexcept {
    if (!data.outputs || data.numOutputs <= 0 || data.numSamples <= 0) return;
    for (int32 bus = 0; bus < data.numOutputs; ++bus) {
        auto& out = data.outputs[bus];
        const int32 channels = out.numChannels;
        if (data.symbolicSampleSize == kSample32 && out.channelBuffers32) {
            for (int32 ch = 0; ch < channels; ++ch)
                if (out.channelBuffers32[ch])
                    std::memset(out.channelBuffers32[ch], 0, sizeof(Sample32) * static_cast<std::size_t>(data.numSamples));
        } else if (data.symbolicSampleSize == kSample64 && out.channelBuffers64) {
            for (int32 ch = 0; ch < channels; ++ch)
                if (out.channelBuffers64[ch])
                    std::memset(out.channelBuffers64[ch], 0, sizeof(Sample64) * static_cast<std::size_t>(data.numSamples));
        }
        out.silenceFlags = (channels >= 64) ? ~uint64(0) : ((uint64(1) << channels) - 1u);
    }
}

bool isUserParameter(ParamID raw) noexcept {
    const auto id = static_cast<ID>(raw);
    const auto* spec = deeser::param::find(id);
    return spec && !spec->readOnly;
}

struct QueueCursor {
    IParamValueQueue* queue = nullptr;
    int32 point = 0;
    int32 count = 0;
    int32 offset = 0;
    ParamValue value = 0.0;
    bool valid = false;
};

bool loadPoint(QueueCursor& c) noexcept {
    c.valid = false;
    if (!c.queue || c.point >= c.count) return false;
    int32 offset = 0;
    ParamValue value = 0.0;
    if (c.queue->getPoint(c.point, offset, value) != kResultTrue) return false;
    c.offset = std::max<int32>(0, offset);
    c.value = value;
    c.valid = true;
    return true;
}
} // namespace

DeEsserProcessor::DeEsserProcessor() { setControllerClass(FUID::fromTUID(DeEsserControllerUID)); }

tresult PLUGIN_API DeEsserProcessor::initialize(FUnknown* context) {
    const auto r = AudioEffect::initialize(context);
    if (r != kResultTrue) return r;
    addAudioInput(STR16("Stereo In"), SpeakerArr::kStereo);
    addAudioOutput(STR16("Stereo Out"), SpeakerArr::kStereo);
    return kResultTrue;
}

tresult PLUGIN_API DeEsserProcessor::terminate() {
    dsp_.reset();
    return AudioEffect::terminate();
}

tresult PLUGIN_API DeEsserProcessor::setupProcessing(ProcessSetup& setup) {
    const auto r = AudioEffect::setupProcessing(setup);
    if (r != kResultTrue) return r;
    dsp_.prepare(setup.sampleRate, static_cast<std::size_t>(std::max(1, setup.maxSamplesPerBlock)),
                 static_cast<std::size_t>(std::max(1, configuredChannels_)));
    syncDSP();
    latencySamples_ = dsp_.latencySamples();
    return kResultTrue;
}

tresult PLUGIN_API DeEsserProcessor::setActive(TBool state) {
    if (state) {
        dsp_.reset();
        syncDSP();
    }
    return AudioEffect::setActive(state);
}

tresult PLUGIN_API DeEsserProcessor::setBusArrangements(SpeakerArrangement* inputs, int32 numIns,
                                                          SpeakerArrangement* outputs, int32 numOuts) {
    if (!inputs || !outputs || numIns != 1 || numOuts != 1 || inputs[0] != outputs[0]) return kResultFalse;
    const int32 channels = SpeakerArr::getChannelCount(inputs[0]);
    if (channels != 1 && channels != 2) return kResultFalse;
    const auto r = AudioEffect::setBusArrangements(inputs, numIns, outputs, numOuts);
    if (r == kResultOk) configuredChannels_ = channels;
    return r;
}

tresult PLUGIN_API DeEsserProcessor::canProcessSampleSize(int32 symbolicSampleSize) {
    return (symbolicSampleSize == kSample32 || symbolicSampleSize == kSample64) ? kResultTrue : kResultFalse;
}

void DeEsserProcessor::applyNormalizedParam(ParamID rawId, ParamValue normalized) noexcept {
    const auto id = static_cast<ID>(rawId);
    if (deeser::param::isMeter(id)) return;
    const double plain = deeser::param::toPlain(id, normalized);
    switch (id) {
        case ID::Sensitivity: params_.sensitivity = static_cast<float>(plain / 100.0); break;
        case ID::Amount: params_.amount = static_cast<float>(plain / 100.0); break;
        case ID::FocusHz: params_.focusHz = static_cast<float>(plain); break;
        case ID::MaxReductionDb: params_.maxReductionDb = static_cast<float>(plain); break;
        case ID::AutoMode: params_.autoMode = normalized >= 0.5; break;
        case ID::Listen: params_.listen = normalized >= 0.5; break;
        case ID::StereoLink: params_.stereoLink = normalized >= 0.5; break;
        case ID::Bypass: params_.bypass = normalized >= 0.5; break;
        case ID::Musicality: params_.musicality = static_cast<float>(plain / 100.0); break;
        case ID::AirProtect: params_.airProtect = static_cast<float>(plain / 100.0); break;
        default: break;
    }
}

void DeEsserProcessor::syncDSP() noexcept {
    dsp_.setParameters(params_);
    params_ = dsp_.parameters();
}

void DeEsserProcessor::pushMeters(IParameterChanges* changes, int32 sampleOffset) noexcept {
    if (!changes) return;
    const auto m = dsp_.meters();
    struct Item { ID id; double plain; };
    const Item values[] = {
        {ID::MeterInputDb, std::max(-60.0, std::min(6.0, static_cast<double>(m.inputPeakDb)))},
        {ID::MeterOutputDb, std::max(-60.0, std::min(6.0, static_cast<double>(m.outputPeakDb)))},
        {ID::MeterGainReductionDb, std::max(0.0, std::min(18.0, static_cast<double>(m.gainReductionDb)))},
        {ID::MeterDetector, std::max(0.0, std::min(1.0, static_cast<double>(m.detector)))},
        {ID::MeterDetectedFrequencyHz, std::max(0.0, std::min(12000.0, static_cast<double>(m.detectedFrequencyHz)))}
    };
    auto pushOne = [&](ID id, double plain) noexcept {
        int32 index = 0;
        if (auto* q = changes->addParameterData(static_cast<ParamID>(id), index)) {
            int32 point = 0;
            q->addPoint(sampleOffset, deeser::param::toNormalized(id, plain), point);
        }
    };
    for (const auto& item : values) pushOne(item.id, item.plain);
    for (std::size_t i = 0; i < deeser::param::analyzerMeterIds.size(); ++i) {
        const double bandDb = std::max(-72.0, std::min(6.0, static_cast<double>(m.analyzerBandDb[i])));
        pushOne(deeser::param::analyzerMeterIds[i], bandDb);
    }
}

tresult PLUGIN_API DeEsserProcessor::process(ProcessData& data) {
    if (data.numSamples < 0) return kInvalidArgument;
    if (data.numSamples == 0) {
        // Apply zero-offset automation even in an empty block and publish live meters.
        if (data.inputParameterChanges) {
            const int32 count = data.inputParameterChanges->getParameterCount();
            bool changed = false;
            for (int32 i = 0; i < count; ++i) {
                if (auto* q = data.inputParameterChanges->getParameterData(i)) {
                    if (!isUserParameter(q->getParameterId()) || q->getPointCount() <= 0) continue;
                    int32 off = 0; ParamValue value = 0.0;
                    if (q->getPoint(q->getPointCount() - 1, off, value) == kResultTrue) {
                        applyNormalizedParam(q->getParameterId(), value);
                        changed = true;
                    }
                }
            }
            if (changed) syncDSP();
        }
        pushMeters(data.outputParameterChanges, 0);
        return kResultTrue;
    }

    if (!data.inputs || !data.outputs || data.numInputs < 1 || data.numOutputs < 1) {
        clearOutputs(data);
        return kResultTrue;
    }

    const int32 channels = std::min(data.inputs[0].numChannels, data.outputs[0].numChannels);
    const int32 useChannels = std::min<int32>(2, channels);
    if (useChannels <= 0) {
        clearOutputs(data);
        return kResultTrue;
    }

    auto processRange32 = [&](int32 start, int32 count) -> bool {
        if (count <= 0) return true;
        if (!data.inputs[0].channelBuffers32 || !data.outputs[0].channelBuffers32) return false;
        const Sample32* in[2] = {nullptr, nullptr};
        Sample32* out[2] = {nullptr, nullptr};
        for (int32 ch = 0; ch < useChannels; ++ch) {
            if (!data.inputs[0].channelBuffers32[ch] || !data.outputs[0].channelBuffers32[ch]) return false;
            in[ch] = data.inputs[0].channelBuffers32[ch] + start;
            out[ch] = data.outputs[0].channelBuffers32[ch] + start;
        }
        dsp_.process(in, out, static_cast<std::size_t>(useChannels), static_cast<std::size_t>(count));
        return true;
    };

    auto processRange64 = [&](int32 start, int32 count) -> bool {
        if (count <= 0) return true;
        if (!data.inputs[0].channelBuffers64 || !data.outputs[0].channelBuffers64) return false;
        const Sample64* in[2] = {nullptr, nullptr};
        Sample64* out[2] = {nullptr, nullptr};
        for (int32 ch = 0; ch < useChannels; ++ch) {
            if (!data.inputs[0].channelBuffers64[ch] || !data.outputs[0].channelBuffers64[ch]) return false;
            in[ch] = data.inputs[0].channelBuffers64[ch] + start;
            out[ch] = data.outputs[0].channelBuffers64[ch] + start;
        }
        dsp_.process(in, out, static_cast<std::size_t>(useChannels), static_cast<std::size_t>(count));
        return true;
    };

    if (data.symbolicSampleSize != kSample32 && data.symbolicSampleSize != kSample64) return kResultFalse;

    // Sample-accurate automation without heap allocation on the audio thread.
    std::array<QueueCursor, 32> cursors{};
    int32 cursorCount = 0;
    if (data.inputParameterChanges) {
        const int32 queueCount = data.inputParameterChanges->getParameterCount();
        for (int32 i = 0; i < queueCount && cursorCount < static_cast<int32>(cursors.size()); ++i) {
            auto* q = data.inputParameterChanges->getParameterData(i);
            if (!q || !isUserParameter(q->getParameterId())) continue;
            auto& c = cursors[static_cast<std::size_t>(cursorCount)];
            c.queue = q;
            c.count = q->getPointCount();
            c.point = 0;
            if (c.count > 0 && loadPoint(c)) ++cursorCount;
        }
    }

    int32 position = 0;
    while (position < data.numSamples) {
        int32 nextOffset = data.numSamples;
        for (int32 i = 0; i < cursorCount; ++i) {
            const auto& c = cursors[static_cast<std::size_t>(i)];
            if (c.valid) nextOffset = std::min(nextOffset, std::max(position, std::min(c.offset, data.numSamples)));
        }

        if (nextOffset > position) {
            const int32 count = nextOffset - position;
            const bool ok = (data.symbolicSampleSize == kSample32) ? processRange32(position, count)
                                                                   : processRange64(position, count);
            if (!ok) return kResultFalse;
            position = nextOffset;
        }

        bool changed = false;
        for (int32 i = 0; i < cursorCount; ++i) {
            auto& c = cursors[static_cast<std::size_t>(i)];
            while (c.valid && std::max(position, std::min(c.offset, data.numSamples)) == position) {
                applyNormalizedParam(c.queue->getParameterId(), c.value);
                changed = true;
                ++c.point;
                if (!loadPoint(c)) break;
            }
        }
        if (changed) syncDSP();

        // No more events at/after this position: finish the block.
        bool any = false;
        for (int32 i = 0; i < cursorCount; ++i) if (cursors[static_cast<std::size_t>(i)].valid) { any = true; break; }
        if (!any && position < data.numSamples) {
            const int32 count = data.numSamples - position;
            const bool ok = (data.symbolicSampleSize == kSample32) ? processRange32(position, count)
                                                                   : processRange64(position, count);
            if (!ok) return kResultFalse;
            position = data.numSamples;
        }
    }

    data.outputs[0].silenceFlags = 0; // Conservative: lookahead can contain valid delayed audio.
    pushMeters(data.outputParameterChanges, data.numSamples - 1);
    return kResultTrue;
}

tresult PLUGIN_API DeEsserProcessor::setState(IBStream* state) {
    if (!state) return kResultFalse;
    IBStreamer s(state, kLittleEndian);
    int32 magic = 0, version = 0;
    if (!s.readInt32(magic) || !s.readInt32(version)) return kResultFalse;
    if (static_cast<std::uint32_t>(magic) != deeser::state::kMagic ||
        version != static_cast<int32>(deeser::state::kVersion)) return kResultFalse;

    std::array<float, deeser::state::kValueCount> values{};
    for (float& v : values) if (!s.readFloat(v)) return kResultFalse;
    params_ = deeser::state::fromValues(values);
    syncDSP();
    return kResultOk;
}

tresult PLUGIN_API DeEsserProcessor::getState(IBStream* state) {
    if (!state) return kResultFalse;
    IBStreamer s(state, kLittleEndian);
    if (!s.writeInt32(static_cast<int32>(deeser::state::kMagic)) ||
        !s.writeInt32(static_cast<int32>(deeser::state::kVersion))) return kResultFalse;
    const auto values = deeser::state::toValues(params_);
    for (float v : values) if (!s.writeFloat(v)) return kResultFalse;
    return kResultOk;
}

} // namespace Steinberg::Vst

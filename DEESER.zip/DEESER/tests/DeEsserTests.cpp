#include "deeser/DeEsserDSP.h"
#include "ParameterContract.h"
#include "StateContract.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <limits>
#include <vector>

namespace {
constexpr double kPi = 3.14159265358979323846;

float rms(const std::vector<float>& x, std::size_t start) {
    double s = 0.0; std::size_t n = 0;
    for (std::size_t i = start; i < x.size(); ++i) { s += double(x[i]) * double(x[i]); ++n; }
    return n ? static_cast<float>(std::sqrt(s / double(n))) : 0.0f;
}
float db(float g) { return 20.0f * std::log10(std::max(g, 1.0e-9f)); }

void processMono(deeser::DeEsserDSP& dsp, const std::vector<float>& in, std::vector<float>& out, std::size_t block) {
    out.assign(in.size(), 0.0f);
    for (std::size_t pos = 0; pos < in.size();) {
        const std::size_t n = std::min(block, in.size() - pos);
        const float* ip[1] = {in.data() + pos}; float* op[1] = {out.data() + pos};
        dsp.process(ip, op, 1, n); pos += n;
    }
}

void processMonoDouble(deeser::DeEsserDSP& dsp, const std::vector<double>& in, std::vector<double>& out, std::size_t block) {
    out.assign(in.size(), 0.0);
    for (std::size_t pos = 0; pos < in.size();) {
        const std::size_t n = std::min(block, in.size() - pos);
        const double* ip[1] = {in.data() + pos}; double* op[1] = {out.data() + pos};
        dsp.process(ip, op, 1, n); pos += n;
    }
}

void processStereo(deeser::DeEsserDSP& dsp, const std::vector<float>& l, const std::vector<float>& r,
                   std::vector<float>& ol, std::vector<float>& orr, std::size_t block) {
    ol.assign(l.size(), 0.0f); orr.assign(r.size(), 0.0f);
    for (std::size_t pos = 0; pos < l.size();) {
        const std::size_t n = std::min(block, l.size() - pos);
        const float* ip[2] = {l.data() + pos, r.data() + pos}; float* op[2] = {ol.data() + pos, orr.data() + pos};
        dsp.process(ip, op, 2, n); pos += n;
    }
}


float toneAmplitude(const std::vector<float>& x, double sr, double hz, std::size_t start) {
    double c = 0.0, q = 0.0; std::size_t n = 0;
    for (std::size_t i = start; i < x.size(); ++i) {
        const double ph = 2.0 * kPi * hz * double(i) / sr;
        c += double(x[i]) * std::cos(ph);
        q += double(x[i]) * std::sin(ph);
        ++n;
    }
    if (!n) return 0.0f;
    return static_cast<float>(2.0 * std::sqrt(c*c + q*q) / double(n));
}

float meanAbsDiff(const std::vector<float>& a, const std::vector<float>& b, std::size_t start) {
    double s = 0.0; std::size_t n = 0;
    for (std::size_t i = start; i < std::min(a.size(), b.size()); ++i) { s += std::fabs(double(a[i]) - double(b[i])); ++n; }
    return n ? static_cast<float>(s / double(n)) : 0.0f;
}

std::vector<float> makeStim(std::size_t n, double sr, double hf) {
    std::vector<float> x(n);
    for (std::size_t i = 0; i < n; ++i) {
        const double t = double(i) / sr;
        x[i] = 0.18f * std::sin(float(2.0 * kPi * 1200.0 * t))
             + 0.13f * std::sin(float(2.0 * kPi * hf * t));
    }
    return x;
}
}

int main() {
    constexpr double sr = 48000.0;
    constexpr std::size_t N = 48000;

    // Parameter contract: unique IDs, valid defaults, reversible normalized/plain mapping.
    {
        std::array<std::uint32_t, deeser::param::specs.size()> ids{};
        for (std::size_t i = 0; i < deeser::param::specs.size(); ++i) {
            const auto& s = deeser::param::specs[i];
            ids[i] = static_cast<std::uint32_t>(s.id);
            if (s.defaultPlain < s.minPlain || s.defaultPlain > s.maxPlain) return 10;
            const double n = deeser::param::toNormalized(s.id, s.defaultPlain);
            const double p = deeser::param::toPlain(s.id, n);
            if (std::fabs(p - s.defaultPlain) > 1.0e-9) return 11;
        }
        std::sort(ids.begin(), ids.end());
        if (std::adjacent_find(ids.begin(), ids.end()) != ids.end()) return 12;
        for (std::size_t i = 0; i < deeser::param::spectrumMeterCount; ++i) {
            const auto raw = static_cast<std::uint32_t>(deeser::param::spectrumMeterId(i));
            if (std::find(ids.begin(), ids.end(), raw) != ids.end()) return 43;
            if (!deeser::param::isMeter(deeser::param::spectrumMeterId(i))) return 44;
        }
    }

    // State contract round trip.
    {
        deeser::Parameters a{}; a.sensitivity = 0.91f; a.musicality = 0.44f; a.airProtect = 0.23f; a.focusHz = 7777.0f; a.listen = true;
        const auto vals = deeser::state::toValues(a);
        const auto b = deeser::state::fromValues(vals);
        if (std::fabs(a.sensitivity - b.sensitivity) > 1e-7f || std::fabs(a.musicality - b.musicality) > 1e-7f ||
            std::fabs(a.airProtect - b.airProtect) > 1e-7f || std::fabs(a.focusHz - b.focusHz) > 1e-4f || a.listen != b.listen) return 13;
    }

    deeser::DeEsserDSP dsp;
    dsp.prepare(sr, 1024, 2);
    const std::size_t L = dsp.latencySamples();
    if (L < 118 || L > 122) { std::cerr << "Latency mismatch: " << L << "\n"; return 14; }

    // Non-sibilant voiced tone must remain exact delayed dry (no permanent HF split/coloration).
    std::vector<float> in(N), out;
    for (std::size_t i = 0; i < N; ++i) in[i] = 0.2f * std::sin(float(2.0 * kPi * 1000.0 * double(i) / sr));
    processMono(dsp, in, out, 137);
    float maxErr = 0.0f;
    for (std::size_t i = L + 1024; i < N; ++i) maxErr = std::max(maxErr, std::fabs(out[i] - in[i - L]));
    if (maxErr > 2.0e-6f) { std::cerr << "Transparency failed " << maxErr << "\n"; return 1; }

    // Strong 7 kHz event must reduce materially and report real GR + frequency.
    dsp.reset();
    deeser::Parameters p{}; p.sensitivity = 0.78f; p.amount = 1.0f; p.maxReductionDb = 10.0f; p.autoMode = true; p.airProtect = 0.2f;
    dsp.setParameters(p);
    in = makeStim(N, sr, 7000.0);
    processMono(dsp, in, out, 257);
    const float inHF = toneAmplitude(in, sr, 7000.0, 8192);
    const float outHF = toneAmplitude(out, sr, 7000.0, 8192 + L);
    const float reduction = db(inHF / std::max(outHF, 1.0e-9f));
    const auto m = dsp.meters();
    if (reduction < 2.0f) { std::cerr << "HF reduction too small " << reduction << " dB\n"; return 2; }
    if (m.gainReductionDb <= 0.2f || m.detector <= 0.02f) return 3;
    if (m.gainReductionDb > p.maxReductionDb + 0.05f) return 36;
    if (m.detectedFrequencyHz < 5000.0f || m.detectedFrequencyHz > 9000.0f) { std::cerr << "Detected Hz " << m.detectedFrequencyHz << "\n"; return 4; }

    // Real analyzer must be driven by detector energy and identify the 7 kHz region.
    {
        std::size_t peak = 0;
        for (std::size_t i = 1; i < m.analyzerBandDb.size(); ++i)
            if (m.analyzerBandDb[i] > m.analyzerBandDb[peak]) peak = i;
        const double peakHz = deeser::param::analyzerCenterHz[peak];
        if (peakHz < 5400.0 || peakHz > 8000.0) {
            std::cerr << "Analyzer peak Hz " << peakHz << "\n"; return 37;
        }
        if (m.analyzerBandDb[peak] <= -50.0f) return 38;
        for (float v : m.analyzerBandDb) if (!std::isfinite(v)) return 39;
    }

    // Full lightweight FFT spectrum must be real, finite and place the 7 kHz peak correctly.
    {
        std::size_t peak = 0;
        float peakDb = -200.0f;
        for (std::size_t i = 0; i < m.spectrumDb.size(); ++i) {
            const double hz = deeser::param::spectrumCenterHz(i);
            if (hz >= 2500.0 && hz <= 14000.0 && m.spectrumDb[i] > peakDb) { peak = i; peakDb = m.spectrumDb[i]; }
        }
        const double peakHz = deeser::param::spectrumCenterHz(peak);
        if (peakHz < 6000.0 || peakHz > 8200.0) {
            std::cerr << "FFT spectrum peak Hz " << peakHz << "\n"; return 40;
        }
        if (m.spectrumDb[peak] <= -35.0f) {
            std::cerr << "FFT spectrum peak level " << m.spectrumDb[peak] << "\n"; return 41;
        }
        for (float v : m.spectrumDb) if (!std::isfinite(v)) return 42;
    }

    // Bypass is exact delayed dry.
    dsp.reset(); p.bypass = true; dsp.setParameters(p);
    for (std::size_t i = 0; i < N; ++i) in[i] = float((int(i % 97) - 48) / 100.0);
    processMono(dsp, in, out, 64);
    maxErr = 0.0f;
    for (std::size_t i = L + 16; i < N; ++i) maxErr = std::max(maxErr, std::fabs(out[i] - in[i - L]));
    if (maxErr != 0.0f) return 5;

    // Every user control changes real audio under an appropriate stimulus.
    {
        const std::size_t M = 32000; std::vector<float> a, b;
        const auto stim7 = makeStim(M, sr, 7000.0);
        auto render = [&](deeser::Parameters q, const std::vector<float>& src, std::vector<float>& dst) {
            dsp.prepare(sr, 512, 2); dsp.setParameters(q); processMono(dsp, src, dst, 127);
        };

        deeser::Parameters q{}; q.amount = 0.0f; render(q, stim7, a); q.amount = 1.0f; render(q, stim7, b);
        if (meanAbsDiff(a, b, 6000) < 1e-5f) return 20;

        q = {}; q.sensitivity = 0.05f; render(q, stim7, a); q.sensitivity = 1.0f; render(q, stim7, b);
        if (meanAbsDiff(a, b, 6000) < 1e-6f) return 21;

        q = {}; q.autoMode = false; q.focusHz = 3800.0f; render(q, stim7, a); q.focusHz = 7600.0f; render(q, stim7, b);
        if (meanAbsDiff(a, b, 6000) < 1e-6f) return 22;

        q = {}; q.amount = 1.0f; q.sensitivity = 1.0f; q.maxReductionDb = 2.0f; render(q, stim7, a); q.maxReductionDb = 16.0f; render(q, stim7, b);
        if (meanAbsDiff(a, b, 6000) < 1e-6f) return 23;

        q = {}; q.autoMode = false; q.focusHz = 5200.0f; render(q, stim7, a); q.autoMode = true; render(q, stim7, b);
        if (meanAbsDiff(a, b, 6000) < 1e-6f) return 24;

        q = {}; q.amount = 1.0f; q.sensitivity = 1.0f; q.listen = false; render(q, stim7, a); q.listen = true; render(q, stim7, b);
        if (meanAbsDiff(a, b, 6000) < 1e-4f) return 25;

        q = {}; q.amount = 1.0f; q.sensitivity = 0.85f; q.musicality = 0.0f; render(q, stim7, a); q.musicality = 1.0f; render(q, stim7, b);
        if (meanAbsDiff(a, b, 6000) < 1e-7f) return 26;

        const auto stim11 = makeStim(M, sr, 11200.0);
        q = {}; q.amount = 1.0f; q.sensitivity = 0.9f; q.airProtect = 0.0f; render(q, stim11, a); q.airProtect = 1.0f; render(q, stim11, b);
        if (meanAbsDiff(a, b, 6000) < 1e-7f) return 27;

        std::vector<float> left = stim7, right(M), al, ar, bl, br;
        for (std::size_t i = 0; i < M; ++i) right[i] = 0.18f * std::sin(float(2.0 * kPi * 1000.0 * double(i) / sr));
        q = {}; q.amount = 1.0f; q.sensitivity = 0.85f; q.stereoLink = false;
        dsp.prepare(sr, 512, 2); dsp.setParameters(q); processStereo(dsp, left, right, al, ar, 127);
        q.stereoLink = true; dsp.prepare(sr, 512, 2); dsp.setParameters(q); processStereo(dsp, left, right, bl, br, 127);
        if (meanAbsDiff(ar, br, 6000) < 1e-8f) return 28;
    }


    // Amount=0 is exact delayed dry even with a strong sibilant stimulus.
    {
        dsp.prepare(sr, 512, 1);
        deeser::Parameters q{}; q.amount = 0.0f; q.sensitivity = 1.0f; q.autoMode = true;
        dsp.setParameters(q);
        const auto src = makeStim(24000, sr, 7200.0);
        std::vector<float> dst; processMono(dsp, src, dst, 113);
        const std::size_t lat = dsp.latencySamples();
        float e = 0.0f;
        for (std::size_t i = lat + 512; i < src.size(); ++i) e = std::max(e, std::fabs(dst[i] - src[i-lat]));
        if (e > 2.0e-6f) return 29;
    }

    // Input/output meters are driven by real signal level in bypass.
    {
        dsp.prepare(sr, 512, 1);
        deeser::Parameters q{}; q.bypass = true; dsp.setParameters(q);
        std::vector<float> src(12000), dst;
        for (std::size_t i = 0; i < src.size(); ++i) src[i] = 0.25f * std::sin(float(2.0 * kPi * 1000.0 * double(i) / sr));
        processMono(dsp, src, dst, 127);
        const auto mm = dsp.meters();
        if (mm.inputPeakDb < -13.0f || mm.inputPeakDb > -11.0f) return 33;
        if (mm.outputPeakDb < -13.0f || mm.outputPeakDb > -11.0f) return 34;
        if (mm.gainReductionDb != 0.0f) return 35;
    }

    // Double precision processing path is real and finite.
    {
        dsp.prepare(sr, 512, 1); dsp.setParameters(deeser::Parameters{});
        std::vector<double> a(8192), b;
        for (std::size_t i = 0; i < a.size(); ++i) a[i] = 0.15 * std::sin(2.0 * kPi * 6800.0 * double(i) / sr);
        processMonoDouble(dsp, a, b, 73);
        for (double v : b) if (!std::isfinite(v)) return 30;
    }

    // NaN/Inf protection.
    dsp.prepare(sr, 256, 1); dsp.setParameters(deeser::Parameters{});
    in.assign(2048, 0.0f); in[10] = std::numeric_limits<float>::quiet_NaN(); in[20] = std::numeric_limits<float>::infinity();
    processMono(dsp, in, out, 111);
    for (float v : out) if (!std::isfinite(v)) return 31;

    // Sample-rate and block-size stability.
    for (double testSr : {44100.0, 48000.0, 88200.0, 96000.0, 192000.0}) {
        for (std::size_t bs : {1u, 7u, 17u, 64u, 257u, 513u}) {
            dsp.prepare(testSr, 1024, 2); dsp.setParameters(deeser::Parameters{});
            std::vector<float> a(4096), b;
            for (std::size_t i = 0; i < a.size(); ++i) a[i] = 0.1f * std::sin(float(2.0 * kPi * 500.0 * double(i) / testSr));
            processMono(dsp, a, b, bs);
            for (float v : b) if (!std::isfinite(v)) return 32;
        }
    }

    std::cout << "Silveton De-Esser core tests passed\n";
    return 0;
}

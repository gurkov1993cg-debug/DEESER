# Silveton De-Esser 1.0.0

Direct Steinberg VST3 SDK de-esser for Intel macOS, with an independent C++ DSP core and native Cocoa/AppKit editor.

## DSP design
- adaptive seven-zone sibilance detector from 3.6 kHz to 11.8 kHz
- 2.5 ms lookahead with reported VST3 latency
- no permanent split-band/EQ coloration when no sibilance is detected
- localized subtractive dynamic attenuation only during detected events
- soft-knee detector response
- program-dependent attack/hold/release
- tonal protection to reduce lisping/over-processing of stable harmonics
- Air Protect for the highest vocal-air region
- mono and stereo processing, optional stereo link
- 32-bit and 64-bit sample paths
- allocation-free audio processing after prepare()

## User controls
Sensitivity, Amount, Frequency, Max GR, Musicality, Air Protect, Auto, Listen, Stereo Link and Bypass.

All visible controls are real VST3 parameters and affect DSP. Continuous controls support numeric entry in the native editor; knob double-click restores the parameter default. Frequency is intentionally inactive/dimmed while Auto is enabled and becomes the real processing focus when Auto is disabled.

## Real meters
Input peak, output peak, gain reduction, sibilance activity and live detected frequency. Meter values originate from DSP and are exported as read-only VST3 parameters. The UI peak-hold indicators are derived only from those real meter values.

## Build baseline
The project uses the locked direct-Steinberg build architecture:
- macos-15-intel
- Xcode 16.4
- CMake Xcode generator
- Release / C++17 / -O3
- x86_64 only
- macOS deployment target 10.13
- vst3sdk 3cdf9ca5d1f5b1b21e0a86832aa4abe55607bd96
- recursive submodules
- smtg_enable_vst3_sdk()
- smtg_add_vst3plugin()
- pluginfactory_constexpr.h / BEGIN_FACTORY_DEF(..., 2)
- Steinberg macmain.cpp entry point
- ad-hoc signing and Steinberg validator

## Locked VST3 identities
Processor and Controller FUIDs are defined in `plugin/DeEsserIDs.h` and must not be changed in later revisions.

## Verification
The source package contains core DSP/parameter/state tests. GitHub Actions additionally verifies SDK revisions, CMake integration, macmain.cpp, x86_64 architecture, macOS 10.13 deployment target, bundleEntry/bundleExit/GetPluginFactory exports, signing, validator and artifact generation.

A green CI build proves build/package/automated validation. Final host compatibility is proven only by scan/load/open/play testing in the target DAW on the target Mac.


## v1.1.0 UI / analyzer update
- Reorganized controls into DETECT -> REDUCE -> PROTECT.
- Real detector-bank spectrum analyzer (3.6/4.4/5.4/6.6/8.0/9.8/11.8 kHz).
- Analyzer highlights the strongest real band and the detected sibilance frequency.
- Manual focus can be set directly by clicking the analyzer.
- Focus value shows AUTO and is disabled while Auto Focus is active.
- No analyzer value is decorative; all seven bins are fed from DSP detector energy.

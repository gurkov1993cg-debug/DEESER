#pragma once

#include "public.sdk/source/common/pluginview.h"

namespace Steinberg::Vst {
class DeEsserController;

class NativeEditor final : public Steinberg::CPluginView {
public:
    explicit NativeEditor(DeEsserController* controller);
    ~NativeEditor() override;

    tresult PLUGIN_API isPlatformTypeSupported(FIDString type) SMTG_OVERRIDE;
    tresult PLUGIN_API attached(void* parent, FIDString type) SMTG_OVERRIDE;
    tresult PLUGIN_API removed() SMTG_OVERRIDE;
    tresult PLUGIN_API onSize(ViewRect* newSize) SMTG_OVERRIDE;
    tresult PLUGIN_API canResize() SMTG_OVERRIDE { return kResultFalse; }
    tresult PLUGIN_API checkSizeConstraint(ViewRect*) SMTG_OVERRIDE { return kResultFalse; }

    DeEsserController* controller() const noexcept { return controller_; }

private:
    DeEsserController* controller_ = nullptr;
    void* nativeView_ = nullptr;
};

} // namespace Steinberg::Vst

#include "NativeEditor.h"
#include "DeEsserController.h"
#include "ParameterContract.h"

#include "pluginterfaces/gui/iplugview.h"
#include "pluginterfaces/vst/ivsteditcontroller.h"

#import <Cocoa/Cocoa.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace Steinberg::Vst {
namespace {
using deeser::param::ID;

constexpr CGFloat kWidth = 900.0;
constexpr CGFloat kHeight = 520.0;
constexpr CGFloat kKnobRadius = 38.0;

struct KnobSpec {
    ID id;
    const char* label;
    CGFloat x;
    CGFloat y;
    const char* suffix;
};

constexpr std::array<KnobSpec, 6> kKnobs{{
    {ID::Sensitivity, "SENSITIVITY", 145.0, 205.0, "%"},
    {ID::Amount, "AMOUNT", 273.0, 205.0, "%"},
    {ID::FocusHz, "FREQUENCY", 401.0, 205.0, ""},
    {ID::MaxReductionDb, "MAX GR", 529.0, 205.0, " dB"},
    {ID::Musicality, "MUSICALITY", 657.0, 205.0, "%"},
    {ID::AirProtect, "AIR PROTECT", 785.0, 205.0, "%"},
}};

struct ToggleSpec {
    ID id;
    const char* label;
    CGFloat x;
};

constexpr std::array<ToggleSpec, 4> kToggles{{
    {ID::AutoMode, "AUTO", 245.0},
    {ID::Listen, "LISTEN", 365.0},
    {ID::StereoLink, "ST LINK", 485.0},
    {ID::Bypass, "BYPASS", 605.0},
}};

NSColor* bg() { return [NSColor colorWithCalibratedRed:0.055 green:0.061 blue:0.071 alpha:1.0]; }
NSColor* panel() { return [NSColor colorWithCalibratedRed:0.080 green:0.088 blue:0.102 alpha:1.0]; }
NSColor* panel2() { return [NSColor colorWithCalibratedRed:0.102 green:0.112 blue:0.128 alpha:1.0]; }
NSColor* accent() { return [NSColor colorWithCalibratedRed:0.18 green:0.68 blue:0.96 alpha:1.0]; }
NSColor* accentDim() { return [NSColor colorWithCalibratedRed:0.12 green:0.36 blue:0.52 alpha:1.0]; }
NSColor* textMain() { return [NSColor colorWithCalibratedWhite:0.91 alpha:1.0]; }
NSColor* textDim() { return [NSColor colorWithCalibratedWhite:0.54 alpha:1.0]; }
NSColor* meterGreen() { return [NSColor colorWithCalibratedRed:0.20 green:0.86 blue:0.43 alpha:1.0]; }
NSColor* meterYellow() { return [NSColor colorWithCalibratedRed:0.96 green:0.78 blue:0.20 alpha:1.0]; }
NSColor* meterRed() { return [NSColor colorWithCalibratedRed:0.96 green:0.28 blue:0.25 alpha:1.0]; }

void fillRounded(NSRect r, CGFloat radius, NSColor* c) {
    [c setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}

void strokeRounded(NSRect r, CGFloat radius, NSColor* c, CGFloat width = 1.0) {
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    [p setLineWidth:width];
    [p stroke];
}

void drawText(NSString* s, NSRect r, CGFloat size, NSColor* c, NSTextAlignment align = NSTextAlignmentCenter, NSFontWeight weight = NSFontWeightRegular) {
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = align;
    NSDictionary* attrs = @{
        NSFontAttributeName: [NSFont systemFontOfSize:size weight:weight],
        NSForegroundColorAttributeName: c,
        NSParagraphStyleAttributeName: ps
    };
    [s drawInRect:r withAttributes:attrs];
}

NSString* formatPlain(ID id, double plain) {
    switch (id) {
        case ID::Sensitivity:
        case ID::Amount:
        case ID::Musicality:
        case ID::AirProtect:
            return [NSString stringWithFormat:@"%.0f%%", plain];
        case ID::FocusHz:
            return plain >= 1000.0 ? [NSString stringWithFormat:@"%.2f kHz", plain / 1000.0]
                                   : [NSString stringWithFormat:@"%.0f Hz", plain];
        case ID::MaxReductionDb:
            return [NSString stringWithFormat:@"%.1f dB", plain];
        default:
            return [NSString stringWithFormat:@"%.2f", plain];
    }
}

NSRect knobHitRect(const KnobSpec& k) { return NSMakeRect(k.x - 50.0, k.y - 55.0, 100.0, 118.0); }
NSRect valueRect(const KnobSpec& k) { return NSMakeRect(k.x - 52.0, k.y + 48.0, 104.0, 24.0); }
NSRect toggleRect(const ToggleSpec& t) { return NSMakeRect(t.x, 365.0, 96.0, 31.0); }

bool isContinuousUserParam(ID id) {
    return id == ID::Sensitivity || id == ID::Amount || id == ID::FocusHz ||
           id == ID::MaxReductionDb || id == ID::Musicality || id == ID::AirProtect;
}

} // namespace

class NativeEditor;

@interface SilvetonDeEsserNSView : NSView <NSTextFieldDelegate> {
@private
    Steinberg::Vst::NativeEditor* _owner;
    NSTimer* _timer;
    NSInteger _dragKnob;
    CGFloat _lastDragY;
    NSTextField* _numericEditor;
    NSInteger _numericKnob;
    double _lastTick;
    double _inputHoldDb;
    double _outputHoldDb;
    double _grHoldDb;
    double _inputHoldUntil;
    double _outputHoldUntil;
    double _grHoldUntil;
}
- (instancetype)initWithFrame:(NSRect)frame owner:(Steinberg::Vst::NativeEditor*)owner;
- (void)shutdown;
@end

@implementation SilvetonDeEsserNSView

- (instancetype)initWithFrame:(NSRect)frame owner:(Steinberg::Vst::NativeEditor*)owner {
    self = [super initWithFrame:frame];
    if (self) {
        _owner = owner;
        _dragKnob = -1;
        _numericKnob = -1;
        _lastTick = [NSDate timeIntervalSinceReferenceDate];
        _inputHoldDb = _outputHoldDb = -60.0;
        _grHoldDb = 0.0;
        [self setWantsLayer:YES];
        _timer = [NSTimer scheduledTimerWithTimeInterval:(1.0 / 30.0)
                                                  target:self
                                                selector:@selector(uiTick:)
                                                userInfo:nil
                                                 repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (void)shutdown {
    [_timer invalidate];
    _timer = nil;
    if (_numericEditor) {
        [_numericEditor removeFromSuperview];
        _numericEditor = nil;
    }
    _owner = nullptr;
}

- (double)normalized:(ID)id {
    if (!_owner || !_owner->controller()) return deeser::param::defaultNormalized(id);
    return _owner->controller()->getParamNormalized(static_cast<ParamID>(id));
}

- (void)setNormalized:(ID)id value:(double)value gesture:(BOOL)gesture {
    if (!_owner || !_owner->controller()) return;
    auto* c = _owner->controller();
    value = std::max(0.0, std::min(1.0, value));
    if (gesture) c->beginEdit(static_cast<ParamID>(id));
    c->setParamNormalized(static_cast<ParamID>(id), value);
    c->performEdit(static_cast<ParamID>(id), value);
    if (gesture) c->endEdit(static_cast<ParamID>(id));
    [self setNeedsDisplay:YES];
}

- (void)uiTick:(NSTimer*)timer {
    (void)timer;
    const double now = [NSDate timeIntervalSinceReferenceDate];
    const double dt = std::max(0.0, std::min(0.25, now - _lastTick));
    _lastTick = now;

    const double inDb = deeser::param::toPlain(ID::MeterInputDb, [self normalized:ID::MeterInputDb]);
    const double outDb = deeser::param::toPlain(ID::MeterOutputDb, [self normalized:ID::MeterOutputDb]);
    const double grDb = deeser::param::toPlain(ID::MeterGainReductionDb, [self normalized:ID::MeterGainReductionDb]);

    auto updatePeak = [&](double current, double& hold, double& until, double decayPerSecond, bool greaterIsPeak) {
        const bool newPeak = greaterIsPeak ? (current > hold) : (current < hold);
        if (newPeak) { hold = current; until = now + 0.85; }
        else if (now > until) {
            if (greaterIsPeak) hold = std::max(current, hold - decayPerSecond * dt);
            else hold = std::min(current, hold + decayPerSecond * dt);
        }
    };
    updatePeak(inDb, _inputHoldDb, _inputHoldUntil, 24.0, true);
    updatePeak(outDb, _outputHoldDb, _outputHoldUntil, 24.0, true);
    if (grDb > _grHoldDb) { _grHoldDb = grDb; _grHoldUntil = now + 0.85; }
    else if (now > _grHoldUntil) _grHoldDb = std::max(grDb, _grHoldDb - 8.0 * dt);

    [self setNeedsDisplay:YES];
}

- (void)drawMeter:(NSRect)r db:(double)db hold:(double)hold title:(NSString*)title gr:(BOOL)isGR {
    fillRounded(r, 4.0, [NSColor colorWithCalibratedWhite:0.025 alpha:1.0]);
    strokeRounded(r, 4.0, [NSColor colorWithCalibratedWhite:0.20 alpha:1.0]);

    double norm = 0.0;
    double holdNorm = 0.0;
    if (isGR) {
        norm = std::max(0.0, std::min(1.0, db / 18.0));
        holdNorm = std::max(0.0, std::min(1.0, hold / 18.0));
    } else {
        norm = std::max(0.0, std::min(1.0, (db + 60.0) / 66.0));
        holdNorm = std::max(0.0, std::min(1.0, (hold + 60.0) / 66.0));
    }

    [NSGraphicsContext saveGraphicsState];
    [[NSBezierPath bezierPathWithRoundedRect:NSInsetRect(r, 2.0, 2.0) xRadius:2.0 yRadius:2.0] addClip];
    const CGFloat h = (r.size.height - 4.0) * norm;
    const CGFloat x = r.origin.x + 2.0;
    const CGFloat w = r.size.width - 4.0;
    const CGFloat bottom = NSMaxY(r) - 2.0;
    const CGFloat y = bottom - h;
    NSRect active = NSMakeRect(x, y, w, h);

    {
        const CGFloat fullH = r.size.height - 4.0;
        const CGFloat greenH = fullH * (isGR ? 0.34 : 0.70);
        const CGFloat yellowH = fullH * (isGR ? 0.33 : 0.20);
        NSRect green = NSMakeRect(x, bottom - greenH, w, greenH);
        NSRect yellow = NSMakeRect(x, bottom - greenH - yellowH, w, yellowH);
        NSRect red = NSMakeRect(x, r.origin.y + 2.0, w, fullH - greenH - yellowH);
        [[NSBezierPath bezierPathWithRect:active] addClip];
        [meterGreen() setFill]; NSRectFill(green);
        [meterYellow() setFill]; NSRectFill(yellow);
        [meterRed() setFill]; NSRectFill(red);
    }
    [NSGraphicsContext restoreGraphicsState];

    const CGFloat hy = NSMaxY(r) - 2.0 - (r.size.height - 4.0) * holdNorm;
    [[NSColor colorWithCalibratedWhite:0.92 alpha:0.92] setStroke];
    NSBezierPath* hp = [NSBezierPath bezierPath];
    [hp moveToPoint:NSMakePoint(r.origin.x + 1.0, hy)];
    [hp lineToPoint:NSMakePoint(NSMaxX(r) - 1.0, hy)];
    [hp setLineWidth:1.0];
    [hp stroke];

    // Real meter scale labels. Values are derived from the same normalized mapping used by the DSP meters.
    const CGFloat labelX = (r.origin.x < 50.0) ? (NSMaxX(r) + 4.0) : ((r.origin.x > 800.0) ? (r.origin.x - 32.0) : (NSMaxX(r) + 4.0));
    const CGFloat labelW = 28.0;
    if (isGR) {
        const double marks[] = {0.0, 6.0, 12.0, 18.0};
        for (double mark : marks) {
            const double n = mark / 18.0;
            const CGFloat yy = NSMaxY(r) - 2.0 - (r.size.height - 4.0) * n - 6.0;
            drawText([NSString stringWithFormat:@"%.0f", mark], NSMakeRect(labelX, yy, labelW, 12.0), 7.5, textDim(), NSTextAlignmentLeft, NSFontWeightRegular);
        }
    } else {
        const double marks[] = {-60.0, -24.0, -12.0, -6.0, 0.0, 6.0};
        for (double mark : marks) {
            const double n = (mark + 60.0) / 66.0;
            const CGFloat yy = NSMaxY(r) - 2.0 - (r.size.height - 4.0) * n - 6.0;
            drawText([NSString stringWithFormat:@"%.0f", mark], NSMakeRect(labelX, yy, labelW, 12.0), 7.5, textDim(), NSTextAlignmentLeft, NSFontWeightRegular);
        }
    }
    drawText(title, NSMakeRect(r.origin.x - 14.0, NSMaxY(r) + 8.0, r.size.width + 28.0, 18.0), 10.0, textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
}

- (void)drawKnob:(const KnobSpec&)k index:(NSInteger)idx {
    const double norm = [self normalized:k.id];
    const BOOL autoOn = [self normalized:ID::AutoMode] >= 0.5;
    const BOOL disabledByAuto = (k.id == ID::FocusHz && autoOn);
    NSColor* arcColor = disabledByAuto ? accentDim() : accent();
    const NSPoint c = NSMakePoint(k.x, k.y);
    const CGFloat r = kKnobRadius;

    [[NSColor colorWithCalibratedWhite:0.18 alpha:1.0] setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x-r, c.y-r, 2*r, 2*r)] fill];
    [[NSColor colorWithCalibratedWhite:0.035 alpha:1.0] setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x-r+5, c.y-r+5, 2*r-10, 2*r-10)] fill];

    constexpr double pi = 3.14159265358979323846;
    const double start = -225.0 * pi / 180.0;
    const double sweep = 270.0 * pi / 180.0;
    NSBezierPath* track = [NSBezierPath bezierPath];
    [track appendBezierPathWithArcWithCenter:c radius:r+7 startAngle:225 endAngle:-45 clockwise:YES];
    [[NSColor colorWithCalibratedWhite:0.17 alpha:1.0] setStroke];
    [track setLineWidth:3.0]; [track stroke];

    NSBezierPath* activeArc = [NSBezierPath bezierPath];
    const CGFloat endDeg = 225.0 - static_cast<CGFloat>(270.0 * norm);
    [activeArc appendBezierPathWithArcWithCenter:c radius:r+7 startAngle:225 endAngle:endDeg clockwise:YES];
    [arcColor setStroke]; [activeArc setLineWidth:3.0]; [activeArc stroke];

    const double a = start + sweep * norm;
    const NSPoint p = NSMakePoint(c.x + std::cos(a) * (r - 12.0), c.y - std::sin(a) * (r - 12.0));
    [arcColor setStroke];
    NSBezierPath* needle = [NSBezierPath bezierPath];
    [needle moveToPoint:c]; [needle lineToPoint:p]; [needle setLineWidth:2.2]; [needle stroke];

    drawText([NSString stringWithUTF8String:k.label], NSMakeRect(k.x-58, k.y-68, 116, 18), 10.0,
             disabledByAuto ? [textDim() colorWithAlphaComponent:0.55] : textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
    const double plain = deeser::param::toPlain(k.id, norm);
    fillRounded(valueRect(k), 4.0, [NSColor colorWithCalibratedWhite:0.055 alpha:1.0]);
    drawText(formatPlain(k.id, plain), NSInsetRect(valueRect(k), 2, 3), 11.5,
             disabledByAuto ? [textDim() colorWithAlphaComponent:0.62] : textMain(), NSTextAlignmentCenter, NSFontWeightMedium);
    (void)idx;
}

- (void)drawToggle:(const ToggleSpec&)t {
    const BOOL on = [self normalized:t.id] >= 0.5;
    NSRect r = toggleRect(t);
    fillRounded(r, 6.0, on ? [accent() colorWithAlphaComponent:0.20] : panel2());
    strokeRounded(r, 6.0, on ? accent() : [NSColor colorWithCalibratedWhite:0.20 alpha:1.0]);
    drawText([NSString stringWithUTF8String:t.label], NSInsetRect(r, 5, 7), 10.5, on ? accent() : textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    [bg() setFill]; NSRectFill(self.bounds);

    // Header
    fillRounded(NSMakeRect(20, 18, 860, 64), 10.0, panel());
    drawText(@"SILVETON", NSMakeRect(40, 31, 180, 28), 20.0, accent(), NSTextAlignmentLeft, NSFontWeightBold);
    drawText(@"DE-ESSER", NSMakeRect(40, 54, 180, 18), 11.0, textDim(), NSTextAlignmentLeft, NSFontWeightSemibold);

    const double detectedHz = deeser::param::toPlain(ID::MeterDetectedFrequencyHz, [self normalized:ID::MeterDetectedFrequencyHz]);
    NSString* detected = detectedHz > 1.0 ? [NSString stringWithFormat:@"%.2f kHz", detectedHz / 1000.0] : @"—";
    drawText(@"DETECTED SIBILANCE", NSMakeRect(315, 29, 270, 16), 10.0, textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
    drawText(detected, NSMakeRect(315, 43, 270, 31), 23.0, textMain(), NSTextAlignmentCenter, NSFontWeightSemibold);

    const double activity = deeser::param::toPlain(ID::MeterDetector, [self normalized:ID::MeterDetector]);
    NSRect act = NSMakeRect(646, 43, 190, 10);
    fillRounded(act, 5.0, [NSColor colorWithCalibratedWhite:0.04 alpha:1.0]);
    NSRect af = act; af.size.width *= std::max(0.0, std::min(1.0, activity));
    fillRounded(af, 5.0, accent());
    drawText(@"SIBILANCE ACTIVITY", NSMakeRect(646, 58, 190, 14), 9.0, textDim(), NSTextAlignmentCenter, NSFontWeightMedium);

    // Main panel and meters
    fillRounded(NSMakeRect(95, 100, 745, 230), 12.0, panel());
    const double inDb = deeser::param::toPlain(ID::MeterInputDb, [self normalized:ID::MeterInputDb]);
    const double outDb = deeser::param::toPlain(ID::MeterOutputDb, [self normalized:ID::MeterOutputDb]);
    const double grDb = deeser::param::toPlain(ID::MeterGainReductionDb, [self normalized:ID::MeterGainReductionDb]);
    [self drawMeter:NSMakeRect(24, 119, 18, 175) db:inDb hold:_inputHoldDb title:@"IN" gr:NO];
    [self drawMeter:NSMakeRect(864, 119, 18, 175) db:outDb hold:_outputHoldDb title:@"OUT" gr:NO];
    [self drawMeter:NSMakeRect(61, 119, 14, 175) db:grDb hold:_grHoldDb title:@"GR" gr:YES];

    for (NSInteger i = 0; i < (NSInteger)kKnobs.size(); ++i) [self drawKnob:kKnobs[(size_t)i] index:i];

    // Switch row
    fillRounded(NSMakeRect(175, 347, 550, 72), 10.0, panel());
    for (const auto& t : kToggles) [self drawToggle:t];

    drawText(@"Click value for numeric entry  •  Double-click knob = default  •  Mouse wheel = fine adjust",
             NSMakeRect(150, 439, 600, 18), 10.0, textDim(), NSTextAlignmentCenter, NSFontWeightRegular);
    drawText(@"Adaptive spectral detection • 2.5 ms lookahead • program-dependent release • Air Protect",
             NSMakeRect(120, 470, 660, 18), 10.0, [textDim() colorWithAlphaComponent:0.76], NSTextAlignmentCenter, NSFontWeightRegular);
}

- (NSInteger)knobAtPoint:(NSPoint)p valueOnly:(BOOL)valueOnly {
    for (NSInteger i = 0; i < (NSInteger)kKnobs.size(); ++i) {
        const auto& k = kKnobs[(size_t)i];
        if (valueOnly ? NSPointInRect(p, valueRect(k)) : NSPointInRect(p, knobHitRect(k))) return i;
    }
    return -1;
}

- (void)beginNumericForKnob:(NSInteger)idx {
    if (idx < 0 || idx >= (NSInteger)kKnobs.size()) return;
    const auto& k = kKnobs[(size_t)idx];
    if (!isContinuousUserParam(k.id)) return;
    if (k.id == ID::FocusHz && [self normalized:ID::AutoMode] >= 0.5) return;

    if (_numericEditor) [_numericEditor removeFromSuperview];
    _numericKnob = idx;
    NSRect r = valueRect(k);
    _numericEditor = [[NSTextField alloc] initWithFrame:r];
    _numericEditor.delegate = self;
    _numericEditor.alignment = NSTextAlignmentCenter;
    _numericEditor.font = [NSFont systemFontOfSize:12 weight:NSFontWeightMedium];
    _numericEditor.textColor = textMain();
    _numericEditor.backgroundColor = [NSColor colorWithCalibratedWhite:0.08 alpha:1.0];
    _numericEditor.bordered = YES;
    const double plain = deeser::param::toPlain(k.id, [self normalized:k.id]);
    _numericEditor.stringValue = [NSString stringWithFormat:@"%.3f", plain];
    _numericEditor.target = self;
    _numericEditor.action = @selector(commitNumeric:);
    [self addSubview:_numericEditor];
    [self.window makeFirstResponder:_numericEditor];
    [_numericEditor selectText:nil];
}

- (void)commitNumeric:(id)sender {
    (void)sender;
    if (!_numericEditor || _numericKnob < 0 || _numericKnob >= (NSInteger)kKnobs.size()) return;
    const auto& k = kKnobs[(size_t)_numericKnob];
    NSString* raw = [_numericEditor.stringValue stringByReplacingOccurrencesOfString:@"," withString:@"."];
    const double plain = raw.doubleValue;
    [self setNormalized:k.id value:deeser::param::toNormalized(k.id, plain) gesture:YES];
    [_numericEditor removeFromSuperview];
    _numericEditor = nil;
    _numericKnob = -1;
}

- (void)controlTextDidEndEditing:(NSNotification*)obj {
    (void)obj;
    if (_numericEditor) [self commitNumeric:_numericEditor];
}

- (void)mouseDown:(NSEvent*)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    NSInteger valueIdx = [self knobAtPoint:p valueOnly:YES];
    if (valueIdx >= 0) { [self beginNumericForKnob:valueIdx]; return; }

    NSInteger idx = [self knobAtPoint:p valueOnly:NO];
    if (idx >= 0) {
        const auto& k = kKnobs[(size_t)idx];
        if (k.id == ID::FocusHz && [self normalized:ID::AutoMode] >= 0.5) return;
        if (event.clickCount >= 2) {
            [self setNormalized:k.id value:deeser::param::defaultNormalized(k.id) gesture:YES];
            return;
        }
        _dragKnob = idx;
        _lastDragY = p.y;
        if (_owner && _owner->controller()) _owner->controller()->beginEdit(static_cast<ParamID>(k.id));
        return;
    }

    for (const auto& t : kToggles) {
        if (NSPointInRect(p, toggleRect(t))) {
            const double next = event.clickCount >= 2 ? deeser::param::defaultNormalized(t.id)
                                                     : ([self normalized:t.id] >= 0.5 ? 0.0 : 1.0);
            [self setNormalized:t.id value:next gesture:YES];
            return;
        }
    }
}

- (void)mouseDragged:(NSEvent*)event {
    if (_dragKnob < 0 || _dragKnob >= (NSInteger)kKnobs.size() || !_owner || !_owner->controller()) return;
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const auto& k = kKnobs[(size_t)_dragKnob];
    const double scale = (event.modifierFlags & NSEventModifierFlagShift) ? 0.0012 : 0.0045;
    const double next = [self normalized:k.id] + (_lastDragY - p.y) * scale;
    const double clamped = std::max(0.0, std::min(1.0, next));
    auto* c = _owner->controller();
    c->setParamNormalized(static_cast<ParamID>(k.id), clamped);
    c->performEdit(static_cast<ParamID>(k.id), clamped);
    _lastDragY = p.y;
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_dragKnob >= 0 && _dragKnob < (NSInteger)kKnobs.size() && _owner && _owner->controller()) {
        _owner->controller()->endEdit(static_cast<ParamID>(kKnobs[(size_t)_dragKnob].id));
    }
    _dragKnob = -1;
}

- (void)scrollWheel:(NSEvent*)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    NSInteger idx = [self knobAtPoint:p valueOnly:NO];
    if (idx < 0) { [super scrollWheel:event]; return; }
    const auto& k = kKnobs[(size_t)idx];
    if (k.id == ID::FocusHz && [self normalized:ID::AutoMode] >= 0.5) return;
    const double step = (event.modifierFlags & NSEventModifierFlagShift) ? 0.002 : 0.008;
    [self setNormalized:k.id value:[self normalized:k.id] + event.scrollingDeltaY * step gesture:YES];
}

@end

NativeEditor::NativeEditor(DeEsserController* controller)
: CPluginView(nullptr), controller_(controller) {
    setRect(ViewRect(0, 0, static_cast<int32>(kWidth), static_cast<int32>(kHeight)));
    if (controller_) controller_->addRef();
}

NativeEditor::~NativeEditor() {
    if (nativeView_) removed();
    if (controller_) controller_->release();
    controller_ = nullptr;
}

tresult PLUGIN_API NativeEditor::isPlatformTypeSupported(FIDString type) {
    return (type && std::strcmp(type, kPlatformTypeNSView) == 0) ? kResultTrue : kResultFalse;
}

tresult PLUGIN_API NativeEditor::attached(void* parent, FIDString type) {
    if (!parent || isPlatformTypeSupported(type) != kResultTrue || nativeView_) return kResultFalse;
    const auto baseResult = CPluginView::attached(parent, type);
    if (baseResult != kResultOk) return baseResult;

    NSView* parentView = (__bridge NSView*)parent;
    SilvetonDeEsserNSView* view = [[SilvetonDeEsserNSView alloc]
        initWithFrame:NSMakeRect(0.0, 0.0, kWidth, kHeight) owner:this];
    [parentView addSubview:view];
    nativeView_ = (__bridge void*)view;
    return kResultTrue;
}

tresult PLUGIN_API NativeEditor::removed() {
    if (nativeView_) {
        SilvetonDeEsserNSView* view = (__bridge SilvetonDeEsserNSView*)nativeView_;
        [view shutdown];
        [view removeFromSuperview];
        nativeView_ = nullptr;
    }
    return CPluginView::removed();
}

tresult PLUGIN_API NativeEditor::onSize(ViewRect* newSize) {
    if (!newSize) return kInvalidArgument;
    const auto r = CPluginView::onSize(newSize);
    if (nativeView_) {
        SilvetonDeEsserNSView* view = (__bridge SilvetonDeEsserNSView*)nativeView_;
        [view setFrame:NSMakeRect(0.0, 0.0, newSize->getWidth(), newSize->getHeight())];
    }
    return r;
}

} // namespace Steinberg::Vst

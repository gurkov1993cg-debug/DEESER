#include "NativeEditor.h"
#include "DeEsserController.h"
#include "ParameterContract.h"

#include "pluginterfaces/gui/iplugview.h"
#include "pluginterfaces/vst/ivsteditcontroller.h"

#import <Cocoa/Cocoa.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace Steinberg::Vst {
namespace {
using deeser::param::ID;

constexpr CGFloat kWidth = 1000.0;
constexpr CGFloat kHeight = 600.0;
constexpr CGFloat kKnobRadius = 34.0;

struct KnobSpec {
    ID id;
    const char* label;
    CGFloat x;
    CGFloat y;
};

// Logical signal-flow order: DETECT -> REDUCE -> PROTECT.
constexpr std::array<KnobSpec, 6> kKnobs{{
    {ID::Sensitivity, "SENSITIVITY", 160.0, 415.0},
    {ID::FocusHz, "FOCUS", 285.0, 415.0},
    {ID::Amount, "DE-ESS AMOUNT", 445.0, 415.0},
    {ID::MaxReductionDb, "MAX REDUCTION", 570.0, 415.0},
    {ID::Musicality, "MUSICALITY", 735.0, 415.0},
    {ID::AirProtect, "AIR PROTECT", 860.0, 415.0},
}};

struct ToggleSpec {
    ID id;
    const char* label;
    CGFloat x;
    CGFloat y;
    CGFloat w;
};

constexpr ToggleSpec kAutoToggle{ID::AutoMode, "AUTO FOCUS", 157.0, 493.0, 132.0};
constexpr std::array<ToggleSpec, 3> kUtilityToggles{{
    {ID::Listen, "LISTEN REMOVED", 335.0, 549.0, 120.0},
    {ID::StereoLink, "STEREO LINK", 468.0, 549.0, 120.0},
    {ID::Bypass, "BYPASS", 601.0, 549.0, 92.0},
}};

NSColor* bg() { return [NSColor colorWithCalibratedRed:0.048 green:0.054 blue:0.064 alpha:1.0]; }
NSColor* panel() { return [NSColor colorWithCalibratedRed:0.075 green:0.084 blue:0.099 alpha:1.0]; }
NSColor* panel2() { return [NSColor colorWithCalibratedRed:0.099 green:0.110 blue:0.130 alpha:1.0]; }
NSColor* accent() { return [NSColor colorWithCalibratedRed:0.18 green:0.68 blue:0.96 alpha:1.0]; }
NSColor* accentDim() { return [NSColor colorWithCalibratedRed:0.10 green:0.30 blue:0.44 alpha:1.0]; }
NSColor* textMain() { return [NSColor colorWithCalibratedWhite:0.93 alpha:1.0]; }
NSColor* textDim() { return [NSColor colorWithCalibratedWhite:0.56 alpha:1.0]; }
NSColor* meterGreen() { return [NSColor colorWithCalibratedRed:0.20 green:0.86 blue:0.43 alpha:1.0]; }
NSColor* meterYellow() { return [NSColor colorWithCalibratedRed:0.96 green:0.78 blue:0.20 alpha:1.0]; }
NSColor* meterRed() { return [NSColor colorWithCalibratedRed:0.96 green:0.28 blue:0.25 alpha:1.0]; }

void fillRounded(NSRect r, CGFloat radius, NSColor* c) {
    [c setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}

void strokeRounded(NSRect r, CGFloat radius, NSColor* c, CGFloat width = 1.0) {
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    [p setLineWidth:width];
    [p stroke];
}

void drawText(NSString* s, NSRect r, CGFloat size, NSColor* c,
              NSTextAlignment align = NSTextAlignmentCenter,
              NSFontWeight weight = NSFontWeightRegular) {
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = align;
    NSDictionary* attrs = @{
        NSFontAttributeName: [NSFont systemFontOfSize:size weight:weight],
        NSForegroundColorAttributeName: c,
        NSParagraphStyleAttributeName: ps
    };
    [s drawInRect:r withAttributes:attrs];
}

NSString* formatPlain(ID id, double plain) {
    switch (id) {
        case ID::Sensitivity:
        case ID::Amount:
        case ID::Musicality:
        case ID::AirProtect:
            return [NSString stringWithFormat:@"%.0f%%", plain];
        case ID::FocusHz:
            return plain >= 1000.0 ? [NSString stringWithFormat:@"%.2f kHz", plain / 1000.0]
                                   : [NSString stringWithFormat:@"%.0f Hz", plain];
        case ID::MaxReductionDb:
            return [NSString stringWithFormat:@"%.1f dB", plain];
        default:
            return [NSString stringWithFormat:@"%.2f", plain];
    }
}

NSRect knobHitRect(const KnobSpec& k) { return NSMakeRect(k.x - 48.0, k.y - 52.0, 96.0, 112.0); }
NSRect valueRect(const KnobSpec& k) { return NSMakeRect(k.x - 50.0, k.y + 43.0, 100.0, 23.0); }
NSRect toggleRect(const ToggleSpec& t) { return NSMakeRect(t.x, t.y, t.w, 29.0); }
NSRect analyzerPanelRect() { return NSMakeRect(95.0, 100.0, 810.0, 215.0); }
NSRect analyzerPlotRect() { return NSMakeRect(128.0, 132.0, 742.0, 145.0); }

bool isContinuousUserParam(ID id) {
    return id == ID::Sensitivity || id == ID::Amount || id == ID::FocusHz ||
           id == ID::MaxReductionDb || id == ID::Musicality || id == ID::AirProtect;
}

double analyzerXForHz(double hz, NSRect plot) {
    constexpr double lo = 3200.0;
    constexpr double hi = 12000.0;
    hz = std::max(lo, std::min(hi, hz));
    const double n = std::log(hz / lo) / std::log(hi / lo);
    return plot.origin.x + plot.size.width * n;
}

double analyzerHzForX(double x, NSRect plot) {
    constexpr double lo = 3200.0;
    constexpr double hi = 12000.0;
    const double n = std::max(0.0, std::min(1.0, (x - plot.origin.x) / plot.size.width));
    return lo * std::pow(hi / lo, n);
}

double analyzerYForDb(double db, NSRect plot) {
    constexpr double lo = -60.0;
    constexpr double hi = 0.0;
    const double n = std::max(0.0, std::min(1.0, (db - lo) / (hi - lo)));
    return NSMaxY(plot) - n * plot.size.height;
}

} // namespace
} // namespace Steinberg::Vst

// Objective-C declarations must be in global scope.
using namespace Steinberg::Vst;

@interface SilvetonDeEsserNSView : NSView <NSTextFieldDelegate> {
@private
    Steinberg::Vst::NativeEditor* _owner;
    NSTimer* _timer;
    NSInteger _dragKnob;
    CGFloat _lastDragY;
    NSTextField* _numericEditor;
    NSInteger _numericKnob;
    double _lastTick;
    double _inputHoldDb;
    double _outputHoldDb;
    double _grHoldDb;
    double _inputHoldUntil;
    double _outputHoldUntil;
    double _grHoldUntil;
}
- (instancetype)initWithFrame:(NSRect)frame owner:(Steinberg::Vst::NativeEditor*)owner;
- (void)shutdown;
@end

@implementation SilvetonDeEsserNSView

- (instancetype)initWithFrame:(NSRect)frame owner:(Steinberg::Vst::NativeEditor*)owner {
    self = [super initWithFrame:frame];
    if (self) {
        _owner = owner;
        _dragKnob = -1;
        _numericKnob = -1;
        _lastTick = [NSDate timeIntervalSinceReferenceDate];
        _inputHoldDb = _outputHoldDb = -60.0;
        _grHoldDb = 0.0;
        _inputHoldUntil = _outputHoldUntil = _grHoldUntil = 0.0;
        [self setWantsLayer:YES];
        _timer = [NSTimer scheduledTimerWithTimeInterval:(1.0 / 30.0)
                                                  target:self
                                                selector:@selector(uiTick:)
                                                userInfo:nil
                                                 repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (void)shutdown {
    [_timer invalidate];
    _timer = nil;
    if (_numericEditor) {
        [_numericEditor removeFromSuperview];
        _numericEditor = nil;
    }
    _owner = nullptr;
}

- (double)normalized:(ID)id {
    if (!_owner || !_owner->controller()) return deeser::param::defaultNormalized(id);
    return _owner->controller()->getParamNormalized(static_cast<ParamID>(id));
}

- (void)setNormalized:(ID)id value:(double)value gesture:(BOOL)gesture {
    if (!_owner || !_owner->controller()) return;
    auto* c = _owner->controller();
    value = std::max(0.0, std::min(1.0, value));
    if (gesture) c->beginEdit(static_cast<ParamID>(id));
    c->setParamNormalized(static_cast<ParamID>(id), value);
    c->performEdit(static_cast<ParamID>(id), value);
    if (gesture) c->endEdit(static_cast<ParamID>(id));
    [self setNeedsDisplay:YES];
}

- (void)uiTick:(NSTimer*)timer {
    (void)timer;
    const double now = [NSDate timeIntervalSinceReferenceDate];
    const double dt = std::max(0.0, std::min(0.25, now - _lastTick));
    _lastTick = now;

    const double inDb = deeser::param::toPlain(ID::MeterInputDb, [self normalized:ID::MeterInputDb]);
    const double outDb = deeser::param::toPlain(ID::MeterOutputDb, [self normalized:ID::MeterOutputDb]);
    const double grDb = deeser::param::toPlain(ID::MeterGainReductionDb, [self normalized:ID::MeterGainReductionDb]);

    auto updatePeak = [&](double current, double& hold, double& until, double decayPerSecond) {
        if (current > hold) { hold = current; until = now + 0.85; }
        else if (now > until) hold = std::max(current, hold - decayPerSecond * dt);
    };
    updatePeak(inDb, _inputHoldDb, _inputHoldUntil, 24.0);
    updatePeak(outDb, _outputHoldDb, _outputHoldUntil, 24.0);
    if (grDb > _grHoldDb) { _grHoldDb = grDb; _grHoldUntil = now + 0.85; }
    else if (now > _grHoldUntil) _grHoldDb = std::max(grDb, _grHoldDb - 8.0 * dt);

    [self setNeedsDisplay:YES];
}

- (void)drawVerticalMeter:(NSRect)r db:(double)db hold:(double)hold title:(NSString*)title {
    fillRounded(r, 4.0, [NSColor colorWithCalibratedWhite:0.025 alpha:1.0]);
    strokeRounded(r, 4.0, [NSColor colorWithCalibratedWhite:0.20 alpha:1.0]);

    const double norm = std::max(0.0, std::min(1.0, (db + 60.0) / 66.0));
    const double holdNorm = std::max(0.0, std::min(1.0, (hold + 60.0) / 66.0));
    const CGFloat fullH = r.size.height - 4.0;
    const CGFloat h = fullH * norm;
    const CGFloat x = r.origin.x + 2.0;
    const CGFloat w = r.size.width - 4.0;
    const CGFloat bottom = NSMaxY(r) - 2.0;
    const NSRect active = NSMakeRect(x, bottom - h, w, h);

    [NSGraphicsContext saveGraphicsState];
    [[NSBezierPath bezierPathWithRect:active] addClip];
    [meterGreen() setFill]; NSRectFill(NSMakeRect(x, bottom - fullH * 0.70, w, fullH * 0.70));
    [meterYellow() setFill]; NSRectFill(NSMakeRect(x, bottom - fullH * 0.90, w, fullH * 0.20));
    [meterRed() setFill]; NSRectFill(NSMakeRect(x, bottom - fullH, w, fullH * 0.10));
    [NSGraphicsContext restoreGraphicsState];

    const CGFloat hy = bottom - fullH * holdNorm;
    [[NSColor colorWithCalibratedWhite:0.94 alpha:0.95] setStroke];
    NSBezierPath* hp = [NSBezierPath bezierPath];
    [hp moveToPoint:NSMakePoint(r.origin.x + 1.0, hy)];
    [hp lineToPoint:NSMakePoint(NSMaxX(r) - 1.0, hy)];
    [hp setLineWidth:1.0]; [hp stroke];

    drawText(title, NSMakeRect(r.origin.x - 10.0, NSMaxY(r) + 7.0, r.size.width + 20.0, 15.0),
             9.5, textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
}

- (void)drawGRBar:(NSRect)r db:(double)db hold:(double)hold {
    fillRounded(r, 5.0, [NSColor colorWithCalibratedWhite:0.025 alpha:1.0]);
    strokeRounded(r, 5.0, [NSColor colorWithCalibratedWhite:0.20 alpha:1.0]);
    const double n = std::max(0.0, std::min(1.0, db / 18.0));
    const double hn = std::max(0.0, std::min(1.0, hold / 18.0));
    const CGFloat innerW = r.size.width - 4.0;
    const CGFloat y = r.origin.y + 2.0;
    const CGFloat h = r.size.height - 4.0;
    const NSRect active = NSMakeRect(r.origin.x + 2.0, y, innerW * n, h);

    [NSGraphicsContext saveGraphicsState];
    [[NSBezierPath bezierPathWithRect:active] addClip];
    [meterGreen() setFill]; NSRectFill(NSMakeRect(r.origin.x + 2.0, y, innerW / 3.0, h));
    [meterYellow() setFill]; NSRectFill(NSMakeRect(r.origin.x + 2.0 + innerW / 3.0, y, innerW / 3.0, h));
    [meterRed() setFill]; NSRectFill(NSMakeRect(r.origin.x + 2.0 + 2.0 * innerW / 3.0, y, innerW / 3.0, h));
    [NSGraphicsContext restoreGraphicsState];

    const CGFloat hx = r.origin.x + 2.0 + innerW * hn;
    [[NSColor colorWithCalibratedWhite:0.94 alpha:0.95] setStroke];
    NSBezierPath* hp = [NSBezierPath bezierPath];
    [hp moveToPoint:NSMakePoint(hx, r.origin.y + 1.0)];
    [hp lineToPoint:NSMakePoint(hx, NSMaxY(r) - 1.0)];
    [hp setLineWidth:1.0]; [hp stroke];

    drawText(@"GAIN REDUCTION", NSMakeRect(r.origin.x, r.origin.y - 18.0, 130.0, 15.0),
             9.5, textDim(), NSTextAlignmentLeft, NSFontWeightSemibold);
    drawText([NSString stringWithFormat:@"%.1f dB", db], NSMakeRect(NSMaxX(r) - 80.0, r.origin.y - 18.0, 80.0, 15.0),
             10.0, textMain(), NSTextAlignmentRight, NSFontWeightSemibold);
}

- (void)drawAnalyzer {
    const NSRect panelRect = analyzerPanelRect();
    const NSRect plot = analyzerPlotRect();
    fillRounded(panelRect, 12.0, panel());
    strokeRounded(panelRect, 12.0, [NSColor colorWithCalibratedWhite:0.14 alpha:1.0]);

    drawText(@"SIBILANCE ANALYZER", NSMakeRect(panelRect.origin.x + 16.0, panelRect.origin.y + 9.0, 210.0, 18.0),
             11.0, textMain(), NSTextAlignmentLeft, NSFontWeightSemibold);
    drawText(@"REAL DSP DETECTOR BANK  •  3.2–12 kHz", NSMakeRect(panelRect.origin.x + 225.0, panelRect.origin.y + 10.0, 300.0, 17.0),
             9.0, textDim(), NSTextAlignmentLeft, NSFontWeightRegular);

    // dB grid.
    const double dbMarks[] = {-60.0, -36.0, -24.0, -12.0, -6.0, 0.0};
    for (double mark : dbMarks) {
        const CGFloat y = analyzerYForDb(mark, plot);
        [[NSColor colorWithCalibratedWhite:0.16 alpha:0.65] setStroke];
        NSBezierPath* gp = [NSBezierPath bezierPath];
        [gp moveToPoint:NSMakePoint(plot.origin.x, y)];
        [gp lineToPoint:NSMakePoint(NSMaxX(plot), y)];
        [gp setLineWidth:0.6]; [gp stroke];
        drawText([NSString stringWithFormat:@"%.0f", mark], NSMakeRect(plot.origin.x - 28.0, y - 6.0, 24.0, 12.0),
                 7.5, textDim(), NSTextAlignmentRight, NSFontWeightRegular);
    }

    const double hzMarks[] = {4000.0, 5000.0, 6000.0, 8000.0, 10000.0, 12000.0};
    for (double hz : hzMarks) {
        const CGFloat x = analyzerXForHz(hz, plot);
        [[NSColor colorWithCalibratedWhite:0.14 alpha:0.55] setStroke];
        NSBezierPath* gp = [NSBezierPath bezierPath];
        [gp moveToPoint:NSMakePoint(x, plot.origin.y)];
        [gp lineToPoint:NSMakePoint(x, NSMaxY(plot))];
        [gp setLineWidth:0.6]; [gp stroke];
        drawText(hz >= 10000.0 ? [NSString stringWithFormat:@"%.0fk", hz / 1000.0]
                               : [NSString stringWithFormat:@"%.0fk", hz / 1000.0],
                 NSMakeRect(x - 18.0, NSMaxY(plot) + 3.0, 36.0, 13.0),
                 8.0, textDim(), NSTextAlignmentCenter, NSFontWeightRegular);
    }

    std::array<double, 7> bandDb{};
    std::size_t peakIndex = 0;
    double peakDb = -1000.0;
    for (std::size_t i = 0; i < bandDb.size(); ++i) {
        bandDb[i] = deeser::param::toPlain(deeser::param::analyzerMeterIds[i], [self normalized:deeser::param::analyzerMeterIds[i]]);
        if (bandDb[i] > peakDb) { peakDb = bandDb[i]; peakIndex = i; }
    }

    NSBezierPath* area = [NSBezierPath bezierPath];
    NSBezierPath* line = [NSBezierPath bezierPath];
    for (std::size_t i = 0; i < bandDb.size(); ++i) {
        const CGFloat x = analyzerXForHz(deeser::param::analyzerCenterHz[i], plot);
        const CGFloat y = analyzerYForDb(bandDb[i], plot);
        if (i == 0) {
            [line moveToPoint:NSMakePoint(x, y)];
            [area moveToPoint:NSMakePoint(x, NSMaxY(plot))];
            [area lineToPoint:NSMakePoint(x, y)];
        } else {
            [line lineToPoint:NSMakePoint(x, y)];
            [area lineToPoint:NSMakePoint(x, y)];
        }
    }
    const CGFloat lastX = analyzerXForHz(deeser::param::analyzerCenterHz.back(), plot);
    [area lineToPoint:NSMakePoint(lastX, NSMaxY(plot))];
    [area closePath];
    [[accent() colorWithAlphaComponent:0.12] setFill]; [area fill];
    [accent() setStroke]; [line setLineWidth:2.0]; [line stroke];

    for (std::size_t i = 0; i < bandDb.size(); ++i) {
        const CGFloat x = analyzerXForHz(deeser::param::analyzerCenterHz[i], plot);
        const CGFloat y = analyzerYForDb(bandDb[i], plot);
        NSColor* c = (i == peakIndex && peakDb > -59.5) ? meterYellow() : accent();
        [c setFill];
        [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(x - 3.0, y - 3.0, 6.0, 6.0)] fill];
    }

    const BOOL autoOn = [self normalized:ID::AutoMode] >= 0.5;
    const double detectedHz = deeser::param::toPlain(ID::MeterDetectedFrequencyHz, [self normalized:ID::MeterDetectedFrequencyHz]);
    const double activity = deeser::param::toPlain(ID::MeterDetector, [self normalized:ID::MeterDetector]);
    const double focusHz = deeser::param::toPlain(ID::FocusHz, [self normalized:ID::FocusHz]);

    if (autoOn && detectedHz > 1.0 && activity > 0.01) {
        const CGFloat x = analyzerXForHz(detectedHz, plot);
        [[NSColor colorWithCalibratedRed:1.0 green:0.48 blue:0.20 alpha:0.95] setStroke];
        NSBezierPath* p = [NSBezierPath bezierPath];
        [p moveToPoint:NSMakePoint(x, plot.origin.y)]; [p lineToPoint:NSMakePoint(x, NSMaxY(plot))];
        [p setLineWidth:1.4]; [p stroke];
        drawText(@"DETECTED", NSMakeRect(x - 33.0, plot.origin.y + 3.0, 66.0, 13.0),
                 8.0, [NSColor colorWithCalibratedRed:1.0 green:0.58 blue:0.30 alpha:1.0], NSTextAlignmentCenter, NSFontWeightSemibold);
    } else if (!autoOn) {
        const CGFloat x = analyzerXForHz(focusHz, plot);
        [accent() setStroke];
        NSBezierPath* p = [NSBezierPath bezierPath];
        [p moveToPoint:NSMakePoint(x, plot.origin.y)]; [p lineToPoint:NSMakePoint(x, NSMaxY(plot))];
        [p setLineWidth:1.4]; [p stroke];
        drawText(@"FOCUS", NSMakeRect(x - 27.0, plot.origin.y + 3.0, 54.0, 13.0),
                 8.0, accent(), NSTextAlignmentCenter, NSFontWeightSemibold);
    }

    NSString* peakText = peakDb > -59.5
        ? [NSString stringWithFormat:@"PEAK  %.2f kHz  /  %.1f dB", deeser::param::analyzerCenterHz[peakIndex] / 1000.0, peakDb]
        : @"PEAK  —";
    drawText(peakText, NSMakeRect(NSMaxX(panelRect) - 270.0, panelRect.origin.y + 9.0, 250.0, 18.0),
             10.0, textMain(), NSTextAlignmentRight, NSFontWeightSemibold);

    NSString* modeText = autoOn ? @"AUTO: detector chooses the sibilant region"
                                : @"MANUAL: click the analyzer to place FOCUS";
    drawText(modeText, NSMakeRect(plot.origin.x, NSMaxY(plot) + 18.0, plot.size.width, 15.0),
             9.0, autoOn ? textDim() : accent(), NSTextAlignmentCenter, NSFontWeightMedium);
}

- (void)drawKnob:(const KnobSpec&)k index:(NSInteger)idx {
    const double norm = [self normalized:k.id];
    const BOOL autoOn = [self normalized:ID::AutoMode] >= 0.5;
    const BOOL disabledByAuto = (k.id == ID::FocusHz && autoOn);
    NSColor* arcColor = disabledByAuto ? accentDim() : accent();
    const NSPoint c = NSMakePoint(k.x, k.y);
    const CGFloat r = kKnobRadius;

    [[NSColor colorWithCalibratedWhite:0.18 alpha:1.0] setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x-r, c.y-r, 2*r, 2*r)] fill];
    [[NSColor colorWithCalibratedWhite:0.035 alpha:1.0] setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x-r+5, c.y-r+5, 2*r-10, 2*r-10)] fill];

    constexpr double pi = 3.14159265358979323846;
    const double start = -225.0 * pi / 180.0;
    const double sweep = 270.0 * pi / 180.0;
    NSBezierPath* track = [NSBezierPath bezierPath];
    [track appendBezierPathWithArcWithCenter:c radius:r+7 startAngle:225 endAngle:-45 clockwise:YES];
    [[NSColor colorWithCalibratedWhite:0.17 alpha:1.0] setStroke];
    [track setLineWidth:3.0]; [track stroke];

    NSBezierPath* activeArc = [NSBezierPath bezierPath];
    const CGFloat endDeg = 225.0 - static_cast<CGFloat>(270.0 * norm);
    [activeArc appendBezierPathWithArcWithCenter:c radius:r+7 startAngle:225 endAngle:endDeg clockwise:YES];
    [arcColor setStroke]; [activeArc setLineWidth:3.0]; [activeArc stroke];

    const double a = start + sweep * norm;
    const NSPoint p = NSMakePoint(c.x + std::cos(a) * (r - 11.0), c.y - std::sin(a) * (r - 11.0));
    [arcColor setStroke];
    NSBezierPath* needle = [NSBezierPath bezierPath];
    [needle moveToPoint:c]; [needle lineToPoint:p]; [needle setLineWidth:2.1]; [needle stroke];

    drawText([NSString stringWithUTF8String:k.label], NSMakeRect(k.x-61, k.y-62, 122, 18), 9.5,
             disabledByAuto ? [textDim() colorWithAlphaComponent:0.55] : textDim(),
             NSTextAlignmentCenter, NSFontWeightSemibold);

    fillRounded(valueRect(k), 4.0, [NSColor colorWithCalibratedWhite:0.052 alpha:1.0]);
    NSString* value = disabledByAuto ? @"AUTO" : formatPlain(k.id, deeser::param::toPlain(k.id, norm));
    drawText(value, NSInsetRect(valueRect(k), 2, 3), 11.0,
             disabledByAuto ? [textDim() colorWithAlphaComponent:0.70] : textMain(),
             NSTextAlignmentCenter, NSFontWeightMedium);
    (void)idx;
}

- (void)drawToggle:(const ToggleSpec&)t {
    const BOOL on = [self normalized:t.id] >= 0.5;
    NSRect r = toggleRect(t);
    fillRounded(r, 6.0, on ? [accent() colorWithAlphaComponent:0.20] : panel2());
    strokeRounded(r, 6.0, on ? accent() : [NSColor colorWithCalibratedWhite:0.20 alpha:1.0]);
    NSString* label = [NSString stringWithUTF8String:t.label];
    if (t.id == ID::AutoMode) label = on ? @"AUTO FOCUS" : @"MANUAL FOCUS";
    drawText(label, NSInsetRect(r, 5, 6), 10.0, on ? accent() : textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
}

- (void)drawSection:(NSRect)r title:(NSString*)title subtitle:(NSString*)subtitle {
    fillRounded(r, 10.0, panel());
    strokeRounded(r, 10.0, [NSColor colorWithCalibratedWhite:0.13 alpha:1.0]);
    drawText(title, NSMakeRect(r.origin.x + 12.0, r.origin.y + 10.0, r.size.width - 24.0, 17.0),
             10.5, accent(), NSTextAlignmentLeft, NSFontWeightBold);
    drawText(subtitle, NSMakeRect(r.origin.x + 12.0, r.origin.y + 27.0, r.size.width - 24.0, 15.0),
             8.5, textDim(), NSTextAlignmentLeft, NSFontWeightRegular);
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    [bg() setFill]; NSRectFill(self.bounds);

    // Header: status first, not decorative controls.
    fillRounded(NSMakeRect(20, 18, 960, 64), 10.0, panel());
    drawText(@"SILVETON", NSMakeRect(40, 30, 180, 26), 20.0, accent(), NSTextAlignmentLeft, NSFontWeightBold);
    drawText(@"DE-ESSER", NSMakeRect(40, 54, 180, 16), 10.5, textDim(), NSTextAlignmentLeft, NSFontWeightSemibold);

    const double detectedHz = deeser::param::toPlain(ID::MeterDetectedFrequencyHz, [self normalized:ID::MeterDetectedFrequencyHz]);
    const double activity = deeser::param::toPlain(ID::MeterDetector, [self normalized:ID::MeterDetector]);
    NSString* detected = detectedHz > 1.0 ? [NSString stringWithFormat:@"%.2f kHz", detectedHz / 1000.0] : @"—";
    drawText(@"DETECTED SIBILANCE", NSMakeRect(360, 28, 230, 15), 9.5, textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
    drawText(detected, NSMakeRect(360, 43, 230, 30), 22.0, textMain(), NSTextAlignmentCenter, NSFontWeightSemibold);

    NSRect act = NSMakeRect(730, 42, 205, 10);
    fillRounded(act, 5.0, [NSColor colorWithCalibratedWhite:0.04 alpha:1.0]);
    NSRect af = act; af.size.width *= std::max(0.0, std::min(1.0, activity));
    fillRounded(af, 5.0, accent());
    drawText(@"SIBILANCE ACTIVITY", NSMakeRect(730, 57, 205, 14), 9.0, textDim(), NSTextAlignmentCenter, NSFontWeightMedium);

    [self drawAnalyzer];

    const double inDb = deeser::param::toPlain(ID::MeterInputDb, [self normalized:ID::MeterInputDb]);
    const double outDb = deeser::param::toPlain(ID::MeterOutputDb, [self normalized:ID::MeterOutputDb]);
    const double grDb = deeser::param::toPlain(ID::MeterGainReductionDb, [self normalized:ID::MeterGainReductionDb]);
    [self drawVerticalMeter:NSMakeRect(25, 130, 18, 142) db:inDb hold:_inputHoldDb title:@"IN"];
    [self drawVerticalMeter:NSMakeRect(957, 130, 18, 142) db:outDb hold:_outputHoldDb title:@"OUT"];
    [self drawGRBar:NSMakeRect(120, 306, 760, 11) db:grDb hold:_grHoldDb];

    // Clear workflow sections.
    [self drawSection:NSMakeRect(95, 335, 255, 195) title:@"1  DETECT" subtitle:@"Find the S region; FOCUS works only in MANUAL"];
    [self drawSection:NSMakeRect(365, 335, 270, 195) title:@"2  REDUCE" subtitle:@"Set how much de-essing is allowed"];
    [self drawSection:NSMakeRect(650, 335, 255, 195) title:@"3  PROTECT" subtitle:@"Keep the vocal natural and preserve air"];

    for (NSInteger i = 0; i < (NSInteger)kKnobs.size(); ++i) [self drawKnob:kKnobs[(size_t)i] index:i];
    [self drawToggle:kAutoToggle];

    // Utility row is deliberately separate from the processing flow.
    fillRounded(NSMakeRect(300, 541, 430, 43), 9.0, panel());
    for (const auto& t : kUtilityToggles) [self drawToggle:t];

    drawText(@"Value box = numeric entry   •   double-click knob = default   •   Shift-drag = fine adjustment",
             NSMakeRect(110, 578, 780, 15), 9.0, [textDim() colorWithAlphaComponent:0.82], NSTextAlignmentCenter, NSFontWeightRegular);
}

- (NSInteger)knobAtPoint:(NSPoint)p valueOnly:(BOOL)valueOnly {
    for (NSInteger i = 0; i < (NSInteger)kKnobs.size(); ++i) {
        const auto& k = kKnobs[(size_t)i];
        if (valueOnly ? NSPointInRect(p, valueRect(k)) : NSPointInRect(p, knobHitRect(k))) return i;
    }
    return -1;
}

- (void)beginNumericForKnob:(NSInteger)idx {
    if (idx < 0 || idx >= (NSInteger)kKnobs.size()) return;
    const auto& k = kKnobs[(size_t)idx];
    if (!isContinuousUserParam(k.id)) return;
    if (k.id == ID::FocusHz && [self normalized:ID::AutoMode] >= 0.5) return;

    if (_numericEditor) [_numericEditor removeFromSuperview];
    _numericKnob = idx;
    NSRect r = valueRect(k);
    _numericEditor = [[NSTextField alloc] initWithFrame:r];
    _numericEditor.delegate = self;
    _numericEditor.alignment = NSTextAlignmentCenter;
    _numericEditor.font = [NSFont systemFontOfSize:12 weight:NSFontWeightMedium];
    _numericEditor.textColor = textMain();
    _numericEditor.backgroundColor = [NSColor colorWithCalibratedWhite:0.08 alpha:1.0];
    _numericEditor.bordered = YES;
    const double plain = deeser::param::toPlain(k.id, [self normalized:k.id]);
    _numericEditor.stringValue = [NSString stringWithFormat:@"%.3f", plain];
    _numericEditor.target = self;
    _numericEditor.action = @selector(commitNumeric:);
    [self addSubview:_numericEditor];
    [self.window makeFirstResponder:_numericEditor];
    [_numericEditor selectText:nil];
}

- (void)commitNumeric:(id)sender {
    (void)sender;
    if (!_numericEditor || _numericKnob < 0 || _numericKnob >= (NSInteger)kKnobs.size()) return;
    const auto& k = kKnobs[(size_t)_numericKnob];
    NSString* raw = [_numericEditor.stringValue stringByReplacingOccurrencesOfString:@"," withString:@"."];
    const double plain = raw.doubleValue;
    [self setNormalized:k.id value:deeser::param::toNormalized(k.id, plain) gesture:YES];
    [_numericEditor removeFromSuperview];
    _numericEditor = nil;
    _numericKnob = -1;
}

- (void)controlTextDidEndEditing:(NSNotification*)obj {
    (void)obj;
    if (_numericEditor) [self commitNumeric:_numericEditor];
}

- (void)mouseDown:(NSEvent*)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];

    // In MANUAL mode the analyzer itself becomes the most direct FOCUS control.
    if (NSPointInRect(p, analyzerPlotRect()) && [self normalized:ID::AutoMode] < 0.5) {
        const double normalized = event.clickCount >= 2
            ? deeser::param::defaultNormalized(ID::FocusHz)
            : deeser::param::toNormalized(ID::FocusHz, analyzerHzForX(p.x, analyzerPlotRect()));
        [self setNormalized:ID::FocusHz value:normalized gesture:YES];
        return;
    }

    NSInteger valueIdx = [self knobAtPoint:p valueOnly:YES];
    if (valueIdx >= 0) { [self beginNumericForKnob:valueIdx]; return; }

    NSInteger idx = [self knobAtPoint:p valueOnly:NO];
    if (idx >= 0) {
        const auto& k = kKnobs[(size_t)idx];
        if (k.id == ID::FocusHz && [self normalized:ID::AutoMode] >= 0.5) return;
        if (event.clickCount >= 2) {
            [self setNormalized:k.id value:deeser::param::defaultNormalized(k.id) gesture:YES];
            return;
        }
        _dragKnob = idx;
        _lastDragY = p.y;
        if (_owner && _owner->controller()) _owner->controller()->beginEdit(static_cast<ParamID>(k.id));
        return;
    }

    if (NSPointInRect(p, toggleRect(kAutoToggle))) {
        const double next = event.clickCount >= 2 ? deeser::param::defaultNormalized(ID::AutoMode)
                                                 : ([self normalized:ID::AutoMode] >= 0.5 ? 0.0 : 1.0);
        [self setNormalized:ID::AutoMode value:next gesture:YES];
        return;
    }

    for (const auto& t : kUtilityToggles) {
        if (NSPointInRect(p, toggleRect(t))) {
            const double next = event.clickCount >= 2 ? deeser::param::defaultNormalized(t.id)
                                                     : ([self normalized:t.id] >= 0.5 ? 0.0 : 1.0);
            [self setNormalized:t.id value:next gesture:YES];
            return;
        }
    }
}

- (void)mouseDragged:(NSEvent*)event {
    if (_dragKnob < 0 || _dragKnob >= (NSInteger)kKnobs.size() || !_owner || !_owner->controller()) return;
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const auto& k = kKnobs[(size_t)_dragKnob];
    const double scale = (event.modifierFlags & NSEventModifierFlagShift) ? 0.0012 : 0.0045;
    const double next = [self normalized:k.id] + (_lastDragY - p.y) * scale;
    const double clamped = std::max(0.0, std::min(1.0, next));
    auto* c = _owner->controller();
    c->setParamNormalized(static_cast<ParamID>(k.id), clamped);
    c->performEdit(static_cast<ParamID>(k.id), clamped);
    _lastDragY = p.y;
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_dragKnob >= 0 && _dragKnob < (NSInteger)kKnobs.size() && _owner && _owner->controller()) {
        _owner->controller()->endEdit(static_cast<ParamID>(kKnobs[(size_t)_dragKnob].id));
    }
    _dragKnob = -1;
}

- (void)scrollWheel:(NSEvent*)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    NSInteger idx = [self knobAtPoint:p valueOnly:NO];
    if (idx < 0) { [super scrollWheel:event]; return; }
    const auto& k = kKnobs[(size_t)idx];
    if (k.id == ID::FocusHz && [self normalized:ID::AutoMode] >= 0.5) return;
    const double step = (event.modifierFlags & NSEventModifierFlagShift) ? 0.002 : 0.008;
    [self setNormalized:k.id value:[self normalized:k.id] + event.scrollingDeltaY * step gesture:YES];
}

@end

namespace Steinberg::Vst {

NativeEditor::NativeEditor(DeEsserController* controller)
: CPluginView(nullptr), controller_(controller) {
    setRect(ViewRect(0, 0, static_cast<int32>(kWidth), static_cast<int32>(kHeight)));
    if (controller_) controller_->addRef();
}

NativeEditor::~NativeEditor() {
    if (nativeView_) removed();
    if (controller_) controller_->release();
    controller_ = nullptr;
}

tresult PLUGIN_API NativeEditor::isPlatformTypeSupported(FIDString type) {
    return (type && std::strcmp(type, kPlatformTypeNSView) == 0) ? kResultTrue : kResultFalse;
}

tresult PLUGIN_API NativeEditor::attached(void* parent, FIDString type) {
    if (!parent || isPlatformTypeSupported(type) != kResultTrue || nativeView_) return kResultFalse;
    const auto baseResult = CPluginView::attached(parent, type);
    if (baseResult != kResultOk) return baseResult;

    NSView* parentView = (__bridge NSView*)parent;
    SilvetonDeEsserNSView* view = [[SilvetonDeEsserNSView alloc]
        initWithFrame:NSMakeRect(0.0, 0.0, kWidth, kHeight) owner:this];
    [parentView addSubview:view];
    nativeView_ = (__bridge void*)view;
    return kResultTrue;
}

tresult PLUGIN_API NativeEditor::removed() {
    if (nativeView_) {
        SilvetonDeEsserNSView* view = (__bridge SilvetonDeEsserNSView*)nativeView_;
        [view shutdown];
        [view removeFromSuperview];
        nativeView_ = nullptr;
    }
    return CPluginView::removed();
}

tresult PLUGIN_API NativeEditor::onSize(ViewRect* newSize) {
    if (!newSize) return kInvalidArgument;
    const auto r = CPluginView::onSize(newSize);
    if (nativeView_) {
        SilvetonDeEsserNSView* view = (__bridge SilvetonDeEsserNSView*)nativeView_;
        [view setFrame:NSMakeRect(0.0, 0.0, newSize->getWidth(), newSize->getHeight())];
    }
    return r;
}

} // namespace Steinberg::Vst

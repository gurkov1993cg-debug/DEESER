#include "NativeEditor.h"
#include "DeEsserController.h"
#include "ParameterContract.h"

#include "pluginterfaces/gui/iplugview.h"
#include "pluginterfaces/vst/ivsteditcontroller.h"

#import <Cocoa/Cocoa.h>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace Steinberg::Vst {
namespace {
using deeser::param::ID;

constexpr CGFloat kWidth = 1000.0;
constexpr CGFloat kHeight = 600.0;
constexpr CGFloat kKnobRadius = 31.0;
constexpr double kPi = 3.14159265358979323846;

struct KnobSpec {
    ID id;
    const char* label;
    CGFloat x;
    CGFloat y;
};

// Left-to-right signal flow. Every control remains present; only redundant text was removed.
constexpr std::array<KnobSpec, 6> kKnobs{{
    {ID::Sensitivity, "SENSITIVITY", 145.0, 454.0},
    {ID::FocusHz, "FOCUS", 280.0, 454.0},
    {ID::Amount, "AMOUNT", 430.0, 454.0},
    {ID::MaxReductionDb, "MAX GR", 565.0, 454.0},
    {ID::Musicality, "MUSICALITY", 720.0, 454.0},
    {ID::AirProtect, "AIR PROTECT", 855.0, 454.0},
}};

struct ToggleSpec {
    ID id;
    const char* label;
    CGFloat x;
    CGFloat y;
    CGFloat w;
};

constexpr std::array<ToggleSpec, 4> kToggles{{
    {ID::AutoMode, "AUTO", 280.0, 548.0, 96.0},
    {ID::Listen, "LISTEN", 388.0, 548.0, 96.0},
    {ID::StereoLink, "LINK", 496.0, 548.0, 96.0},
    {ID::Bypass, "BYPASS", 604.0, 548.0, 96.0},
}};

NSColor* bg() { return [NSColor colorWithCalibratedRed:0.042 green:0.048 blue:0.058 alpha:1.0]; }
NSColor* panel() { return [NSColor colorWithCalibratedRed:0.070 green:0.079 blue:0.093 alpha:1.0]; }
NSColor* panel2() { return [NSColor colorWithCalibratedRed:0.092 green:0.103 blue:0.121 alpha:1.0]; }
NSColor* accent() { return [NSColor colorWithCalibratedRed:0.16 green:0.70 blue:0.98 alpha:1.0]; }
NSColor* accentDim() { return [NSColor colorWithCalibratedRed:0.10 green:0.30 blue:0.43 alpha:1.0]; }
NSColor* orange() { return [NSColor colorWithCalibratedRed:1.0 green:0.48 blue:0.17 alpha:1.0]; }
NSColor* textMain() { return [NSColor colorWithCalibratedWhite:0.94 alpha:1.0]; }
NSColor* textDim() { return [NSColor colorWithCalibratedWhite:0.56 alpha:1.0]; }
NSColor* meterGreen() { return [NSColor colorWithCalibratedRed:0.20 green:0.86 blue:0.43 alpha:1.0]; }
NSColor* meterYellow() { return [NSColor colorWithCalibratedRed:0.96 green:0.78 blue:0.20 alpha:1.0]; }
NSColor* meterRed() { return [NSColor colorWithCalibratedRed:0.96 green:0.28 blue:0.25 alpha:1.0]; }

void fillRounded(NSRect r, CGFloat radius, NSColor* c) {
    [c setFill];
    [[NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius] fill];
}

void strokeRounded(NSRect r, CGFloat radius, NSColor* c, CGFloat width = 1.0) {
    [c setStroke];
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];
    [p setLineWidth:width];
    [p stroke];
}

void drawText(NSString* s, NSRect r, CGFloat size, NSColor* c,
              NSTextAlignment align = NSTextAlignmentCenter,
              NSFontWeight weight = NSFontWeightRegular) {
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = align;
    NSDictionary* attrs = @{
        NSFontAttributeName: [NSFont systemFontOfSize:size weight:weight],
        NSForegroundColorAttributeName: c,
        NSParagraphStyleAttributeName: ps
    };
    [s drawInRect:r withAttributes:attrs];
}

NSString* formatPlain(ID id, double plain) {
    switch (id) {
        case ID::Sensitivity:
        case ID::Amount:
        case ID::Musicality:
        case ID::AirProtect:
            return [NSString stringWithFormat:@"%.0f%%", plain];
        case ID::FocusHz:
            return [NSString stringWithFormat:@"%.2f kHz", plain / 1000.0];
        case ID::MaxReductionDb:
            return [NSString stringWithFormat:@"%.1f dB", plain];
        default:
            return [NSString stringWithFormat:@"%.2f", plain];
    }
}

NSRect knobHitRect(const KnobSpec& k) { return NSMakeRect(k.x - 47.0, k.y - 48.0, 94.0, 104.0); }
NSRect valueRect(const KnobSpec& k) { return NSMakeRect(k.x - 47.0, k.y + 41.0, 94.0, 22.0); }
NSRect toggleRect(const ToggleSpec& t) { return NSMakeRect(t.x, t.y, t.w, 28.0); }
NSRect analyzerPanelRect() { return NSMakeRect(54.0, 72.0, 892.0, 300.0); }
NSRect analyzerPlotRect() { return NSMakeRect(82.0, 92.0, 836.0, 244.0); }

bool isContinuousUserParam(ID id) {
    return id == ID::Sensitivity || id == ID::Amount || id == ID::FocusHz ||
           id == ID::MaxReductionDb || id == ID::Musicality || id == ID::AirProtect;
}

double spectrumXForHz(double hz, NSRect plot) {
    constexpr double lo = deeser::param::spectrumMinHz;
    constexpr double hi = deeser::param::spectrumMaxHz;
    hz = std::max(lo, std::min(hi, hz));
    const double n = std::log(hz / lo) / std::log(hi / lo);
    return plot.origin.x + plot.size.width * n;
}

double spectrumHzForX(double x, NSRect plot) {
    constexpr double lo = deeser::param::spectrumMinHz;
    constexpr double hi = deeser::param::spectrumMaxHz;
    const double n = std::max(0.0, std::min(1.0, (x - plot.origin.x) / plot.size.width));
    return lo * std::pow(hi / lo, n);
}

double spectrumYForDb(double db, NSRect plot) {
    constexpr double lo = deeser::param::spectrumMinDb;
    constexpr double hi = deeser::param::spectrumMaxDb;
    const double n = std::max(0.0, std::min(1.0, (db - lo) / (hi - lo)));
    return NSMaxY(plot) - n * plot.size.height;
}

NSPoint knobPoint(NSPoint c, CGFloat radius, double normalized) {
    // Standard audio knob: minimum at ~7:30, midpoint at 12:00, maximum at ~4:30.
    // In this flipped NSView y grows downward, so use y = c.y - sin(theta)*r.
    const double degrees = 225.0 - 270.0 * std::max(0.0, std::min(1.0, normalized));
    const double a = degrees * kPi / 180.0;
    return NSMakePoint(c.x + std::cos(a) * radius, c.y - std::sin(a) * radius);
}

NSBezierPath* knobArc(NSPoint c, CGFloat radius, double endNormalized) {
    NSBezierPath* p = [NSBezierPath bezierPath];
    constexpr int steps = 48;
    const double end = std::max(0.0, std::min(1.0, endNormalized));
    for (int i = 0; i <= steps; ++i) {
        const double n = end * static_cast<double>(i) / static_cast<double>(steps);
        const NSPoint pt = knobPoint(c, radius, n);
        if (i == 0) [p moveToPoint:pt]; else [p lineToPoint:pt];
    }
    return p;
}

} // namespace
} // namespace Steinberg::Vst

using namespace Steinberg::Vst;

@interface SilvetonDeEsserNSView : NSView <NSTextFieldDelegate> {
@private
    Steinberg::Vst::NativeEditor* _owner;
    NSTimer* _timer;
    NSInteger _dragKnob;
    CGFloat _lastDragY;
    NSTextField* _numericEditor;
    NSInteger _numericKnob;
    double _lastTick;
    double _inputHoldDb;
    double _outputHoldDb;
    double _grHoldDb;
    double _inputHoldUntil;
    double _outputHoldUntil;
    double _grHoldUntil;
    double _spectrumDisplay[64];
}
- (instancetype)initWithFrame:(NSRect)frame owner:(Steinberg::Vst::NativeEditor*)owner;
- (void)shutdown;
@end

@implementation SilvetonDeEsserNSView

- (instancetype)initWithFrame:(NSRect)frame owner:(Steinberg::Vst::NativeEditor*)owner {
    self = [super initWithFrame:frame];
    if (self) {
        _owner = owner;
        _dragKnob = -1;
        _numericKnob = -1;
        _lastTick = [NSDate timeIntervalSinceReferenceDate];
        _inputHoldDb = _outputHoldDb = -60.0;
        _grHoldDb = 0.0;
        _inputHoldUntil = _outputHoldUntil = _grHoldUntil = 0.0;
        for (double& v : _spectrumDisplay) v = deeser::param::spectrumMinDb;
        [self setWantsLayer:YES];
        _timer = [NSTimer scheduledTimerWithTimeInterval:(1.0 / 30.0)
                                                  target:self
                                                selector:@selector(uiTick:)
                                                userInfo:nil
                                                 repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
    return self;
}

- (BOOL)isFlipped { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }

- (void)shutdown {
    [_timer invalidate];
    _timer = nil;
    if (_numericEditor) {
        [_numericEditor removeFromSuperview];
        _numericEditor = nil;
    }
    _owner = nullptr;
}

- (double)normalized:(ID)id {
    if (!_owner || !_owner->controller()) return deeser::param::defaultNormalized(id);
    return _owner->controller()->getParamNormalized(static_cast<ParamID>(id));
}

- (void)setNormalized:(ID)id value:(double)value gesture:(BOOL)gesture {
    if (!_owner || !_owner->controller()) return;
    auto* c = _owner->controller();
    value = std::max(0.0, std::min(1.0, value));
    if (gesture) c->beginEdit(static_cast<ParamID>(id));
    c->setParamNormalized(static_cast<ParamID>(id), value);
    c->performEdit(static_cast<ParamID>(id), value);
    if (gesture) c->endEdit(static_cast<ParamID>(id));
    [self setNeedsDisplay:YES];
}

- (void)uiTick:(NSTimer*)timer {
    (void)timer;
    const double now = [NSDate timeIntervalSinceReferenceDate];
    const double dt = std::max(0.0, std::min(0.25, now - _lastTick));
    _lastTick = now;

    const double inDb = deeser::param::toPlain(ID::MeterInputDb, [self normalized:ID::MeterInputDb]);
    const double outDb = deeser::param::toPlain(ID::MeterOutputDb, [self normalized:ID::MeterOutputDb]);
    const double grDb = deeser::param::toPlain(ID::MeterGainReductionDb, [self normalized:ID::MeterGainReductionDb]);

    auto updatePeak = [&](double current, double& hold, double& until, double decayPerSecond) {
        if (current > hold) { hold = current; until = now + 0.85; }
        else if (now > until) hold = std::max(current, hold - decayPerSecond * dt);
    };
    updatePeak(inDb, _inputHoldDb, _inputHoldUntil, 24.0);
    updatePeak(outDb, _outputHoldDb, _outputHoldUntil, 24.0);
    if (grDb > _grHoldDb) { _grHoldDb = grDb; _grHoldUntil = now + 0.85; }
    else if (now > _grHoldUntil) _grHoldDb = std::max(grDb, _grHoldDb - 8.0 * dt);

    // GUI smoothing only follows real FFT values; it never invents a spectrum.
    for (std::size_t i = 0; i < deeser::param::spectrumMeterCount; ++i) {
        const ID id = deeser::param::spectrumMeterId(i);
        const double target = deeser::param::toPlain(id, [self normalized:id]);
        const double coeff = (target > _spectrumDisplay[i]) ? 0.55 : 0.15;
        _spectrumDisplay[i] += (target - _spectrumDisplay[i]) * coeff;
    }
    [self setNeedsDisplay:YES];
}

- (void)drawVerticalMeter:(NSRect)r db:(double)db hold:(double)hold title:(NSString*)title {
    fillRounded(r, 4.0, [NSColor colorWithCalibratedWhite:0.025 alpha:1.0]);
    strokeRounded(r, 4.0, [NSColor colorWithCalibratedWhite:0.20 alpha:1.0]);
    const double norm = std::max(0.0, std::min(1.0, (db + 60.0) / 66.0));
    const double holdNorm = std::max(0.0, std::min(1.0, (hold + 60.0) / 66.0));
    const CGFloat fullH = r.size.height - 4.0;
    const CGFloat h = fullH * norm;
    const CGFloat x = r.origin.x + 2.0;
    const CGFloat w = r.size.width - 4.0;
    const CGFloat bottom = NSMaxY(r) - 2.0;
    const NSRect active = NSMakeRect(x, bottom - h, w, h);
    [NSGraphicsContext saveGraphicsState];
    [[NSBezierPath bezierPathWithRect:active] addClip];
    [meterGreen() setFill]; NSRectFill(NSMakeRect(x, bottom - fullH * 0.70, w, fullH * 0.70));
    [meterYellow() setFill]; NSRectFill(NSMakeRect(x, bottom - fullH * 0.90, w, fullH * 0.20));
    [meterRed() setFill]; NSRectFill(NSMakeRect(x, bottom - fullH, w, fullH * 0.10));
    [NSGraphicsContext restoreGraphicsState];
    const CGFloat hy = bottom - fullH * holdNorm;
    [textMain() setStroke];
    NSBezierPath* hp = [NSBezierPath bezierPath];
    [hp moveToPoint:NSMakePoint(r.origin.x + 1.0, hy)];
    [hp lineToPoint:NSMakePoint(NSMaxX(r) - 1.0, hy)];
    [hp setLineWidth:1.0]; [hp stroke];
    drawText(title, NSMakeRect(r.origin.x - 8.0, NSMaxY(r) + 4.0, r.size.width + 16.0, 13.0),
             8.5, textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
}

- (void)drawGRBar:(NSRect)r db:(double)db hold:(double)hold {
    fillRounded(r, 4.0, [NSColor colorWithCalibratedWhite:0.025 alpha:1.0]);
    const double n = std::max(0.0, std::min(1.0, db / 18.0));
    const double hn = std::max(0.0, std::min(1.0, hold / 18.0));
    NSRect active = NSInsetRect(r, 2.0, 2.0);
    active.size.width *= n;
    [meterYellow() setFill]; NSRectFill(active);
    const CGFloat hx = r.origin.x + 2.0 + (r.size.width - 4.0) * hn;
    [textMain() setStroke];
    NSBezierPath* hp = [NSBezierPath bezierPath];
    [hp moveToPoint:NSMakePoint(hx, r.origin.y + 1.0)];
    [hp lineToPoint:NSMakePoint(hx, NSMaxY(r) - 1.0)];
    [hp setLineWidth:1.0]; [hp stroke];
}

- (void)drawAnalyzer {
    const NSRect panelRect = analyzerPanelRect();
    const NSRect plot = analyzerPlotRect();
    fillRounded(panelRect, 10.0, panel());
    strokeRounded(panelRect, 10.0, [NSColor colorWithCalibratedWhite:0.14 alpha:1.0]);

    // Work range highlight: the spectrum is full-range, the de-esser operates in 3.2-12 kHz.
    const CGFloat workX0 = spectrumXForHz(3200.0, plot);
    const CGFloat workX1 = spectrumXForHz(12000.0, plot);
    [[accent() colorWithAlphaComponent:0.045] setFill];
    NSRectFill(NSMakeRect(workX0, plot.origin.y, workX1 - workX0, plot.size.height));

    const double dbMarks[] = {-72.0, -48.0, -24.0, -12.0, 0.0};
    for (double mark : dbMarks) {
        const CGFloat y = spectrumYForDb(mark, plot);
        [[NSColor colorWithCalibratedWhite:0.15 alpha:0.58] setStroke];
        NSBezierPath* gp = [NSBezierPath bezierPath];
        [gp moveToPoint:NSMakePoint(plot.origin.x, y)];
        [gp lineToPoint:NSMakePoint(NSMaxX(plot), y)];
        [gp setLineWidth:0.6]; [gp stroke];
        drawText([NSString stringWithFormat:@"%.0f", mark], NSMakeRect(plot.origin.x - 27.0, y - 6.0, 23.0, 12.0),
                 7.5, textDim(), NSTextAlignmentRight, NSFontWeightRegular);
    }

    const double hzMarks[] = {100.0, 200.0, 500.0, 1000.0, 2000.0, 5000.0, 10000.0, 20000.0};
    for (double hz : hzMarks) {
        const CGFloat x = spectrumXForHz(hz, plot);
        [[NSColor colorWithCalibratedWhite:0.13 alpha:0.48] setStroke];
        NSBezierPath* gp = [NSBezierPath bezierPath];
        [gp moveToPoint:NSMakePoint(x, plot.origin.y)];
        [gp lineToPoint:NSMakePoint(x, NSMaxY(plot))];
        [gp setLineWidth:0.55]; [gp stroke];
        NSString* label = hz >= 1000.0 ? [NSString stringWithFormat:@"%.0fk", hz / 1000.0]
                                         : [NSString stringWithFormat:@"%.0f", hz];
        drawText(label, NSMakeRect(x - 18.0, NSMaxY(plot) + 4.0, 36.0, 12.0),
                 8.0, textDim(), NSTextAlignmentCenter, NSFontWeightRegular);
    }

    // Real FFT spectrum. 64 transport bins, rendered as one clean continuous trace.
    NSBezierPath* line = [NSBezierPath bezierPath];
    NSBezierPath* area = [NSBezierPath bezierPath];
    double peakDb = deeser::param::spectrumMinDb;
    double peakHz = 0.0;
    NSPoint peakPoint = NSZeroPoint;
    for (std::size_t i = 0; i < deeser::param::spectrumMeterCount; ++i) {
        const double hz = deeser::param::spectrumCenterHz(i);
        const double db = _spectrumDisplay[i];
        const NSPoint pt = NSMakePoint(spectrumXForHz(hz, plot), spectrumYForDb(db, plot));
        if (i == 0) {
            [line moveToPoint:pt];
            [area moveToPoint:NSMakePoint(pt.x, NSMaxY(plot))];
            [area lineToPoint:pt];
        } else {
            [line lineToPoint:pt];
            [area lineToPoint:pt];
        }
        if (hz >= 2500.0 && hz <= 14000.0 && db > peakDb) {
            peakDb = db; peakHz = hz; peakPoint = pt;
        }
    }
    [area lineToPoint:NSMakePoint(NSMaxX(plot), NSMaxY(plot))];
    [area closePath];
    [[accent() colorWithAlphaComponent:0.09] setFill]; [area fill];
    [accent() setStroke]; [line setLineWidth:1.55]; [line stroke];

    if (peakHz > 0.0 && peakDb > -88.0) {
        [meterYellow() setFill];
        [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(peakPoint.x - 2.5, peakPoint.y - 2.5, 5.0, 5.0)] fill];
        NSString* peak = [NSString stringWithFormat:@"PEAK  %.2f kHz   %.1f dB", peakHz / 1000.0, peakDb];
        drawText(peak, NSMakeRect(NSMaxX(plot) - 210.0, plot.origin.y + 7.0, 200.0, 16.0),
                 9.5, textMain(), NSTextAlignmentRight, NSFontWeightSemibold);
    }

    const BOOL autoOn = [self normalized:ID::AutoMode] >= 0.5;
    const double detectedHz = deeser::param::toPlain(ID::MeterDetectedFrequencyHz, [self normalized:ID::MeterDetectedFrequencyHz]);
    const double activity = deeser::param::toPlain(ID::MeterDetector, [self normalized:ID::MeterDetector]);
    const double focusHz = deeser::param::toPlain(ID::FocusHz, [self normalized:ID::FocusHz]);
    const double markerHz = autoOn ? detectedHz : focusHz;
    if (markerHz >= 3200.0 && markerHz <= 12000.0 && (!autoOn || activity > 0.01)) {
        const CGFloat x = spectrumXForHz(markerHz, plot);
        NSColor* mc = autoOn ? orange() : accent();
        [mc setStroke];
        NSBezierPath* marker = [NSBezierPath bezierPath];
        [marker moveToPoint:NSMakePoint(x, plot.origin.y)];
        [marker lineToPoint:NSMakePoint(x, NSMaxY(plot))];
        [marker setLineWidth:1.35]; [marker stroke];
        NSString* label = [NSString stringWithFormat:@"%.2f kHz", markerHz / 1000.0];
        drawText(label, NSMakeRect(x - 40.0, plot.origin.y + 6.0, 80.0, 16.0),
                 9.5, mc, NSTextAlignmentCenter, NSFontWeightSemibold);
    }
}

- (void)drawKnob:(const KnobSpec&)k {
    const double norm = [self normalized:k.id];
    const BOOL autoOn = [self normalized:ID::AutoMode] >= 0.5;
    const BOOL disabledByAuto = (k.id == ID::FocusHz && autoOn);
    NSColor* arcColor = disabledByAuto ? accentDim() : accent();
    const NSPoint c = NSMakePoint(k.x, k.y);
    const CGFloat r = kKnobRadius;

    [[NSColor colorWithCalibratedWhite:0.18 alpha:1.0] setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x-r, c.y-r, 2*r, 2*r)] fill];
    [[NSColor colorWithCalibratedWhite:0.028 alpha:1.0] setFill];
    [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(c.x-r+5, c.y-r+5, 2*r-10, 2*r-10)] fill];

    NSBezierPath* track = knobArc(c, r + 7.0, 1.0);
    [[NSColor colorWithCalibratedWhite:0.18 alpha:1.0] setStroke];
    [track setLineWidth:3.0]; [track stroke];
    NSBezierPath* activeArc = knobArc(c, r + 7.0, norm);
    [arcColor setStroke]; [activeArc setLineWidth:3.0]; [activeArc stroke];

    const NSPoint tip = knobPoint(c, r - 10.0, norm);
    [arcColor setStroke];
    NSBezierPath* needle = [NSBezierPath bezierPath];
    [needle moveToPoint:c]; [needle lineToPoint:tip];
    [needle setLineWidth:2.0]; [needle stroke];

    drawText([NSString stringWithUTF8String:k.label], NSMakeRect(k.x - 60.0, k.y - 55.0, 120.0, 16.0),
             9.5, disabledByAuto ? [textDim() colorWithAlphaComponent:0.45] : textDim(),
             NSTextAlignmentCenter, NSFontWeightSemibold);

    fillRounded(valueRect(k), 4.0, [NSColor colorWithCalibratedWhite:0.052 alpha:1.0]);
    NSString* value = disabledByAuto ? @"AUTO" : formatPlain(k.id, deeser::param::toPlain(k.id, norm));
    drawText(value, NSInsetRect(valueRect(k), 2.0, 3.0), 11.0,
             disabledByAuto ? [textDim() colorWithAlphaComponent:0.65] : textMain(),
             NSTextAlignmentCenter, NSFontWeightMedium);
}

- (void)drawToggle:(const ToggleSpec&)t {
    const BOOL on = [self normalized:t.id] >= 0.5;
    NSRect r = toggleRect(t);
    fillRounded(r, 6.0, on ? [accent() colorWithAlphaComponent:0.18] : panel2());
    strokeRounded(r, 6.0, on ? accent() : [NSColor colorWithCalibratedWhite:0.18 alpha:1.0]);
    NSString* label = [NSString stringWithUTF8String:t.label];
    if (t.id == ID::AutoMode) label = on ? @"AUTO" : @"MANUAL";
    drawText(label, NSInsetRect(r, 5.0, 6.0), 10.0, on ? accent() : textDim(), NSTextAlignmentCenter, NSFontWeightSemibold);
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    [bg() setFill]; NSRectFill(self.bounds);

    drawText(@"SILVETON", NSMakeRect(28, 22, 150, 23), 18.0, accent(), NSTextAlignmentLeft, NSFontWeightBold);
    drawText(@"DE-ESSER", NSMakeRect(28, 44, 150, 14), 9.5, textDim(), NSTextAlignmentLeft, NSFontWeightSemibold);

    const double detectedHz = deeser::param::toPlain(ID::MeterDetectedFrequencyHz, [self normalized:ID::MeterDetectedFrequencyHz]);
    const double grDb = deeser::param::toPlain(ID::MeterGainReductionDb, [self normalized:ID::MeterGainReductionDb]);
    NSString* center = detectedHz > 1.0 ? [NSString stringWithFormat:@"S  %.2f kHz", detectedHz / 1000.0] : @"S  —";
    drawText(center, NSMakeRect(380, 25, 240, 28), 18.0, textMain(), NSTextAlignmentCenter, NSFontWeightSemibold);
    drawText([NSString stringWithFormat:@"GR  %.1f dB", grDb], NSMakeRect(805, 28, 150, 22), 13.0, textMain(), NSTextAlignmentRight, NSFontWeightSemibold);

    [self drawAnalyzer];

    const double inDb = deeser::param::toPlain(ID::MeterInputDb, [self normalized:ID::MeterInputDb]);
    const double outDb = deeser::param::toPlain(ID::MeterOutputDb, [self normalized:ID::MeterOutputDb]);
    [self drawVerticalMeter:NSMakeRect(24, 112, 17, 205) db:inDb hold:_inputHoldDb title:@"IN"];
    [self drawVerticalMeter:NSMakeRect(959, 112, 17, 205) db:outDb hold:_outputHoldDb title:@"OUT"];
    [self drawGRBar:NSMakeRect(82, 348, 836, 8) db:grDb hold:_grHoldDb];

    // Only three short group labels. No instruction paragraphs or duplicate labels.
    drawText(@"DETECT", NSMakeRect(88, 385, 250, 16), 10.0, accent(), NSTextAlignmentCenter, NSFontWeightBold);
    drawText(@"REDUCE", NSMakeRect(365, 385, 265, 16), 10.0, accent(), NSTextAlignmentCenter, NSFontWeightBold);
    drawText(@"PROTECT", NSMakeRect(652, 385, 250, 16), 10.0, accent(), NSTextAlignmentCenter, NSFontWeightBold);

    [[NSColor colorWithCalibratedWhite:0.13 alpha:1.0] setStroke];
    for (CGFloat x : {350.0, 640.0}) {
        NSBezierPath* sep = [NSBezierPath bezierPath];
        [sep moveToPoint:NSMakePoint(x, 397.0)]; [sep lineToPoint:NSMakePoint(x, 520.0)];
        [sep setLineWidth:1.0]; [sep stroke];
    }

    for (const auto& k : kKnobs) [self drawKnob:k];
    for (const auto& t : kToggles) [self drawToggle:t];
}

- (NSInteger)knobAtPoint:(NSPoint)p valueOnly:(BOOL)valueOnly {
    for (NSInteger i = 0; i < (NSInteger)kKnobs.size(); ++i) {
        const auto& k = kKnobs[(size_t)i];
        if (valueOnly ? NSPointInRect(p, valueRect(k)) : NSPointInRect(p, knobHitRect(k))) return i;
    }
    return -1;
}

- (void)beginNumericForKnob:(NSInteger)idx {
    if (idx < 0 || idx >= (NSInteger)kKnobs.size()) return;
    const auto& k = kKnobs[(size_t)idx];
    if (!isContinuousUserParam(k.id)) return;
    if (k.id == ID::FocusHz && [self normalized:ID::AutoMode] >= 0.5) return;
    if (_numericEditor) [_numericEditor removeFromSuperview];
    _numericKnob = idx;
    _numericEditor = [[NSTextField alloc] initWithFrame:valueRect(k)];
    _numericEditor.delegate = self;
    _numericEditor.alignment = NSTextAlignmentCenter;
    _numericEditor.font = [NSFont systemFontOfSize:12 weight:NSFontWeightMedium];
    _numericEditor.textColor = textMain();
    _numericEditor.backgroundColor = [NSColor colorWithCalibratedWhite:0.08 alpha:1.0];
    _numericEditor.bordered = YES;
    const double plain = deeser::param::toPlain(k.id, [self normalized:k.id]);
    _numericEditor.stringValue = [NSString stringWithFormat:@"%.3f", plain];
    _numericEditor.target = self;
    _numericEditor.action = @selector(commitNumeric:);
    [self addSubview:_numericEditor];
    [self.window makeFirstResponder:_numericEditor];
    [_numericEditor selectText:nil];
}

- (void)commitNumeric:(id)sender {
    (void)sender;
    if (!_numericEditor || _numericKnob < 0 || _numericKnob >= (NSInteger)kKnobs.size()) return;
    const auto& k = kKnobs[(size_t)_numericKnob];
    NSString* raw = [_numericEditor.stringValue stringByReplacingOccurrencesOfString:@"," withString:@"."];
    [self setNormalized:k.id value:deeser::param::toNormalized(k.id, raw.doubleValue) gesture:YES];
    [_numericEditor removeFromSuperview];
    _numericEditor = nil;
    _numericKnob = -1;
}

- (void)controlTextDidEndEditing:(NSNotification*)obj {
    (void)obj;
    if (_numericEditor) [self commitNumeric:_numericEditor];
}

- (void)mouseDown:(NSEvent*)event {
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];

    // In MANUAL, clicking the highlighted 3.2-12 kHz region directly sets FOCUS.
    if (NSPointInRect(p, analyzerPlotRect()) && [self normalized:ID::AutoMode] < 0.5) {
        const double hz = spectrumHzForX(p.x, analyzerPlotRect());
        if (hz >= 3200.0 && hz <= 12000.0) {
            const double normalized = event.clickCount >= 2
                ? deeser::param::defaultNormalized(ID::FocusHz)
                : deeser::param::toNormalized(ID::FocusHz, hz);
            [self setNormalized:ID::FocusHz value:normalized gesture:YES];
        }
        return;
    }

    const NSInteger valueIdx = [self knobAtPoint:p valueOnly:YES];
    if (valueIdx >= 0) { [self beginNumericForKnob:valueIdx]; return; }

    const NSInteger idx = [self knobAtPoint:p valueOnly:NO];
    if (idx >= 0) {
        const auto& k = kKnobs[(size_t)idx];
        if (k.id == ID::FocusHz && [self normalized:ID::AutoMode] >= 0.5) return;
        if (event.clickCount >= 2) {
            [self setNormalized:k.id value:deeser::param::defaultNormalized(k.id) gesture:YES];
            return;
        }
        _dragKnob = idx;
        _lastDragY = p.y;
        if (_owner && _owner->controller()) _owner->controller()->beginEdit(static_cast<ParamID>(k.id));
        return;
    }

    for (const auto& t : kToggles) {
        if (NSPointInRect(p, toggleRect(t))) {
            const double next = event.clickCount >= 2 ? deeser::param::defaultNormalized(t.id)
                                                     : ([self normalized:t.id] >= 0.5 ? 0.0 : 1.0);
            [self setNormalized:t.id value:next gesture:YES];
            return;
        }
    }
}

- (void)mouseDragged:(NSEvent*)event {
    if (_dragKnob < 0 || _dragKnob >= (NSInteger)kKnobs.size() || !_owner || !_owner->controller()) return;
    NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const auto& k = kKnobs[(size_t)_dragKnob];
    // Explicit contract: drag UP = increase; drag DOWN = decrease.
    const double scale = (event.modifierFlags & NSEventModifierFlagShift) ? 0.0010 : 0.0040;
    const double deltaUp = static_cast<double>(_lastDragY - p.y);
    const double next = [self normalized:k.id] + deltaUp * scale;
    const double clamped = std::max(0.0, std::min(1.0, next));
    auto* c = _owner->controller();
    c->setParamNormalized(static_cast<ParamID>(k.id), clamped);
    c->performEdit(static_cast<ParamID>(k.id), clamped);
    _lastDragY = p.y;
    [self setNeedsDisplay:YES];
}

- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_dragKnob >= 0 && _dragKnob < (NSInteger)kKnobs.size() && _owner && _owner->controller())
        _owner->controller()->endEdit(static_cast<ParamID>(kKnobs[(size_t)_dragKnob].id));
    _dragKnob = -1;
}

- (void)scrollWheel:(NSEvent*)event {
    // Do not alter parameters from trackpad/mouse natural-scrolling direction; it is OS/user dependent.
    [super scrollWheel:event];
}

@end

namespace Steinberg::Vst {

NativeEditor::NativeEditor(DeEsserController* controller)
: CPluginView(nullptr), controller_(controller) {
    setRect(ViewRect(0, 0, static_cast<int32>(kWidth), static_cast<int32>(kHeight)));
    if (controller_) controller_->addRef();
}

NativeEditor::~NativeEditor() {
    if (nativeView_) removed();
    if (controller_) controller_->release();
    controller_ = nullptr;
}

tresult PLUGIN_API NativeEditor::isPlatformTypeSupported(FIDString type) {
    return (type && std::strcmp(type, kPlatformTypeNSView) == 0) ? kResultTrue : kResultFalse;
}

tresult PLUGIN_API NativeEditor::attached(void* parent, FIDString type) {
    if (!parent || isPlatformTypeSupported(type) != kResultTrue || nativeView_) return kResultFalse;
    const auto baseResult = CPluginView::attached(parent, type);
    if (baseResult != kResultOk) return baseResult;
    NSView* parentView = (__bridge NSView*)parent;
    SilvetonDeEsserNSView* view = [[SilvetonDeEsserNSView alloc]
        initWithFrame:NSMakeRect(0.0, 0.0, kWidth, kHeight) owner:this];
    [parentView addSubview:view];
    nativeView_ = (__bridge void*)view;
    return kResultTrue;
}

tresult PLUGIN_API NativeEditor::removed() {
    if (nativeView_) {
        SilvetonDeEsserNSView* view = (__bridge SilvetonDeEsserNSView*)nativeView_;
        [view shutdown];
        [view removeFromSuperview];
        nativeView_ = nullptr;
    }
    return CPluginView::removed();
}

tresult PLUGIN_API NativeEditor::onSize(ViewRect* newSize) {
    if (!newSize) return kInvalidArgument;
    const auto r = CPluginView::onSize(newSize);
    if (nativeView_) {
        SilvetonDeEsserNSView* view = (__bridge SilvetonDeEsserNSView*)nativeView_;
        [view setFrame:NSMakeRect(0.0, 0.0, newSize->getWidth(), newSize->getHeight())];
    }
    return r;
}

} // namespace Steinberg::Vst

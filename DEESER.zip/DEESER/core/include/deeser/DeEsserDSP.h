#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace deeser {

inline constexpr std::size_t kAnalyzerBandCount = 7;

struct Parameters {
    float sensitivity = 0.60f;       // 0..1
    float amount = 0.75f;            // 0..1
    float focusHz = 6500.0f;         // 3200..12000, manual focus
    float maxReductionDb = 8.0f;     // 1..18
    float musicality = 0.78f;        // 0..1, more protection + smoother recovery
    float airProtect = 0.70f;        // 0..1, protects >~9 kHz air
    bool autoMode = true;
    bool listen = false;
    bool stereoLink = true;
    bool bypass = false;
};

struct Meters {
    float inputPeakDb = -120.0f;
    float outputPeakDb = -120.0f;
    float gainReductionDb = 0.0f;
    float detector = 0.0f;           // 0..1 sibilance confidence/activity
    float detectedFrequencyHz = 0.0f;
    std::array<float, kAnalyzerBandCount> analyzerBandDb{{-72.0f, -72.0f, -72.0f, -72.0f, -72.0f, -72.0f, -72.0f}};
};

class DeEsserDSP {
public:
    void prepare(double sampleRate, std::size_t maxBlockSize, std::size_t channels);
    void reset() noexcept;
    void setParameters(const Parameters& p) noexcept;
    const Parameters& parameters() const noexcept { return params_; }

    // in/out may alias. Processing is allocation-free after prepare().
    void process(const float* const* input, float* const* output,
                 std::size_t channels, std::size_t samples) noexcept;
    void process(const double* const* input, double* const* output,
                 std::size_t channels, std::size_t samples) noexcept;

    std::uint32_t latencySamples() const noexcept { return lookaheadSamples_; }
    Meters meters() const noexcept { return meters_; }

private:
    static constexpr std::size_t kBands = kAnalyzerBandCount;

    struct Biquad {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0;
        double z1 = 0.0, z2 = 0.0;
        void reset() noexcept { z1 = z2 = 0.0; }
        double process(double x) noexcept {
            const double y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            return y;
        }
        void setBandPass(double sr, double freq, double q) noexcept;
    };

    struct ChannelState {
        std::array<Biquad, kBands> detectorFilters{};
        std::array<Biquad, kBands> processFilters{};
        std::array<double, kBands> bandEnv{};
        std::array<double, kBands> weight{};
        Biquad voiceLow{};
        Biquad voiceHigh{};
        double voiceEnv = 0.0;
        double fullEnv = 0.0;
        double grDb = 0.0;
        double detectedHz = 0.0;
        int holdSamples = 0;
        std::vector<double> delay{};
        std::size_t writePos = 0;
        void reset() noexcept;
    };

    struct Target {
        double grDb = 0.0;
        double activity = 0.0;
        double detectedHz = 0.0;
        std::array<double, kBands> weights{};
    };

    static double sanitize(double x) noexcept;
    static double dbToGain(double db) noexcept;
    static double gainToDb(double g) noexcept;
    static double clamp(double v, double lo, double hi) noexcept;
    static double lerp(double a, double b, double t) noexcept;

    void updateCoefficients() noexcept;
    void updateDetector(ChannelState& st, double x) noexcept;
    Target computeTarget(double fullEnv, double voiceEnv,
                         const std::array<double, kBands>& bandEnv) const noexcept;
    Target computeTarget(const ChannelState& st) const noexcept;
    Target linkedTarget(std::size_t channels) const noexcept;

    template <typename Sample>
    void processImpl(const Sample* const* input, Sample* const* output,
                     std::size_t channels, std::size_t samples) noexcept;

    double sampleRate_ = 48000.0;
    std::size_t maxBlockSize_ = 0;
    std::size_t preparedChannels_ = 0;
    std::uint32_t lookaheadSamples_ = 0;

    std::array<double, kBands> bandHz_{{3600.0, 4400.0, 5400.0, 6600.0, 8000.0, 9800.0, 11800.0}};
    Parameters params_{};
    Meters meters_{};
    std::vector<ChannelState> channels_{};

    double detectorAttackCoeff_ = 0.0;
    double detectorReleaseCoeff_ = 0.0;
    double fullReleaseCoeff_ = 0.0;
    double voiceReleaseCoeff_ = 0.0;
    double meterDecayPerSample_ = 1.0;
    double meterInPeak_ = 0.0;
    double meterOutPeak_ = 0.0;
    double meterActivity_ = 0.0;
    std::array<double, kBands> meterBandPeak_{};
    double meterBandDecayPerSample_ = 1.0;
};

} // namespace deeser

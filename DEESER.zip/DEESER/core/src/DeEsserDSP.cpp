#include "deeser/DeEsserDSP.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <type_traits>

namespace deeser {
namespace {
constexpr double kPi = 3.1415926535897932384626433832795;
constexpr double kEps = 1.0e-20;

double timeCoeff(double sr, double seconds) noexcept {
    if (seconds <= 0.0 || sr <= 0.0) return 0.0;
    return std::exp(-1.0 / (sr * seconds));
}
}

void DeEsserDSP::Biquad::setBandPass(double sr, double freq, double q) noexcept {
    const double nyq = std::max(1000.0, sr * 0.5);
    freq = std::max(40.0, std::min(freq, nyq * 0.92));
    q = std::max(0.20, std::min(q, 12.0));
    const double w0 = 2.0 * kPi * freq / sr;
    const double c = std::cos(w0);
    const double s = std::sin(w0);
    const double alpha = s / (2.0 * q);
    const double a0 = 1.0 + alpha;
    b0 = alpha / a0;
    b1 = 0.0;
    b2 = -alpha / a0;
    a1 = (-2.0 * c) / a0;
    a2 = (1.0 - alpha) / a0;
}

void DeEsserDSP::ChannelState::reset() noexcept {
    for (auto& f : detectorFilters) f.reset();
    for (auto& f : processFilters) f.reset();
    voiceLow.reset();
    voiceHigh.reset();
    bandEnv.fill(0.0);
    weight.fill(0.0);
    voiceEnv = 0.0;
    fullEnv = 0.0;
    grDb = 0.0;
    detectedHz = 0.0;
    holdSamples = 0;
    std::fill(delay.begin(), delay.end(), 0.0);
    writePos = 0;
}

double DeEsserDSP::sanitize(double x) noexcept { return std::isfinite(x) ? x : 0.0; }
double DeEsserDSP::dbToGain(double db) noexcept { return std::pow(10.0, db / 20.0); }
double DeEsserDSP::gainToDb(double g) noexcept { return 20.0 * std::log10(std::max(g, 1.0e-9)); }
double DeEsserDSP::clamp(double v, double lo, double hi) noexcept { return std::max(lo, std::min(v, hi)); }
double DeEsserDSP::lerp(double a, double b, double t) noexcept { return a + (b - a) * t; }

void DeEsserDSP::prepare(double sampleRate, std::size_t maxBlockSize, std::size_t channels) {
    sampleRate_ = std::max(8000.0, sampleRate);
    maxBlockSize_ = std::max<std::size_t>(1, maxBlockSize);
    preparedChannels_ = std::max<std::size_t>(1, channels);

    // Fixed latency: enough time to catch the leading edge without making tracking feel sluggish.
    lookaheadSamples_ = static_cast<std::uint32_t>(std::max(1.0, std::round(sampleRate_ * 0.0025)));

    detectorAttackCoeff_ = timeCoeff(sampleRate_, 0.00035);
    detectorReleaseCoeff_ = timeCoeff(sampleRate_, 0.028);
    fullReleaseCoeff_ = timeCoeff(sampleRate_, 0.050);
    voiceReleaseCoeff_ = timeCoeff(sampleRate_, 0.070);
    meterDecayPerSample_ = dbToGain(-18.0 / sampleRate_); // real peak meter decay: 18 dB/s

    channels_.assign(preparedChannels_, ChannelState{});
    const std::size_t delaySize = static_cast<std::size_t>(lookaheadSamples_) + 1u;
    for (auto& ch : channels_) ch.delay.assign(delaySize, 0.0);

    updateCoefficients();
    reset();
}

void DeEsserDSP::reset() noexcept {
    for (auto& ch : channels_) ch.reset();
    meterInPeak_ = meterOutPeak_ = meterActivity_ = 0.0;
    meters_ = {};
    meters_.inputPeakDb = -120.0f;
    meters_.outputPeakDb = -120.0f;
}

void DeEsserDSP::setParameters(const Parameters& p) noexcept {
    params_ = p;
    params_.sensitivity = static_cast<float>(clamp(params_.sensitivity, 0.0, 1.0));
    params_.amount = static_cast<float>(clamp(params_.amount, 0.0, 1.0));
    params_.focusHz = static_cast<float>(clamp(params_.focusHz, 3200.0, 12000.0));
    params_.maxReductionDb = static_cast<float>(clamp(params_.maxReductionDb, 1.0, 18.0));
    params_.musicality = static_cast<float>(clamp(params_.musicality, 0.0, 1.0));
    params_.airProtect = static_cast<float>(clamp(params_.airProtect, 0.0, 1.0));
}

void DeEsserDSP::updateCoefficients() noexcept {
    for (auto& ch : channels_) {
        for (std::size_t i = 0; i < kBands; ++i) {
            ch.detectorFilters[i].setBandPass(sampleRate_, bandHz_[i], 2.05);
            ch.processFilters[i].setBandPass(sampleRate_, bandHz_[i], 2.15);
        }
        ch.voiceLow.setBandPass(sampleRate_, 1400.0, 1.05);
        ch.voiceHigh.setBandPass(sampleRate_, 2600.0, 1.05);
    }
}

void DeEsserDSP::updateDetector(ChannelState& st, double x) noexcept {
    const double x2 = x * x;
    if (x2 > st.fullEnv) st.fullEnv = x2;
    else st.fullEnv = fullReleaseCoeff_ * st.fullEnv + (1.0 - fullReleaseCoeff_) * x2;

    const double v1 = st.voiceLow.process(x);
    const double v2 = st.voiceHigh.process(x);
    const double ve = 0.5 * (v1 * v1 + v2 * v2);
    if (ve > st.voiceEnv) st.voiceEnv = ve;
    else st.voiceEnv = voiceReleaseCoeff_ * st.voiceEnv + (1.0 - voiceReleaseCoeff_) * ve;

    for (std::size_t i = 0; i < kBands; ++i) {
        const double b = st.detectorFilters[i].process(x);
        const double e = b * b;
        const double c = (e > st.bandEnv[i]) ? detectorAttackCoeff_ : detectorReleaseCoeff_;
        st.bandEnv[i] = c * st.bandEnv[i] + (1.0 - c) * e;
    }
}

DeEsserDSP::Target DeEsserDSP::computeTarget(double fullEnv, double voiceEnv,
                                              const std::array<double, kBands>& bandEnv) const noexcept {
    Target t{};
    const double fullDb = 10.0 * std::log10(std::max(fullEnv, kEps));
    if (fullDb < -66.0) return t;

    const double sens = params_.sensitivity;
    const double musicality = params_.musicality;
    const double airProtect = params_.airProtect;
    const double thresholdDb = lerp(-7.5, -24.0, sens);
    const double reference = std::max(voiceEnv * 0.80 + fullEnv * 0.10, kEps);

    std::array<double, kBands> excess{};
    double sumExcess = 0.0;
    double maxExcess = 0.0;
    double sumBand = 0.0;
    double maxBand = 0.0;
    double logSum = 0.0;

    for (std::size_t i = 0; i < kBands; ++i) {
        sumBand += bandEnv[i];
        maxBand = std::max(maxBand, bandEnv[i]);
        logSum += std::log(std::max(bandEnv[i], kEps));
    }
    const double arithmetic = sumBand / static_cast<double>(kBands) + kEps;
    const double geometric = std::exp(logSum / static_cast<double>(kBands));
    const double flatness = clamp(geometric / arithmetic, 0.0, 1.0);
    const double dominance = clamp(maxBand / std::max(sumBand, kEps), 0.0, 1.0);

    // Reject ordinary voiced material before the sensitive ratio detector.
    // This gate is relative, not a fixed level threshold, so quiet real sibilants can still trigger.
    const double hfShareDb = 10.0 * std::log10((sumBand + kEps) / (fullEnv + kEps));
    const double hfGateDb = lerp(-5.0, -16.0, sens);
    if (hfShareDb < hfGateDb) return t;

    for (std::size_t i = 0; i < kBands; ++i) {
        const double ratioDb = 10.0 * std::log10((bandEnv[i] + kEps) / reference);
        double e = std::max(0.0, ratioDb - thresholdDb);

        // Manual mode is still analyzed across the whole bank, but only the chosen region acts.
        if (!params_.autoMode) {
            const double oct = std::log2(std::max(1.0, bandHz_[i]) / std::max(1.0f, params_.focusHz));
            const double sigma = lerp(0.18, 0.34, musicality);
            e *= std::exp(-0.5 * (oct * oct) / (sigma * sigma));
        }

        // Preserve the highest "air" octave; lower bins remain free to do the actual de-essing.
        const double airPos = clamp((bandHz_[i] - 8500.0) / 3500.0, 0.0, 1.0);
        e *= (1.0 - 0.68 * airProtect * airPos);

        excess[i] = e;
        sumExcess += e;
        maxExcess = std::max(maxExcess, e);
    }
    if (sumExcess <= 1.0e-12) return t;

    // Broadband/noisy HF energy is more likely to be a real sibilant than a stable whistle/harmonic.
    const double broadnessFactor = 0.78 + 0.22 * std::sqrt(flatness);
    const double tonalProtect = 1.0 - musicality * 0.42 * clamp((dominance - 0.38) / 0.62, 0.0, 1.0);
    maxExcess *= broadnessFactor * tonalProtect;

    double centroid = 0.0;
    for (std::size_t i = 0; i < kBands; ++i) {
        t.weights[i] = excess[i] / sumExcess;
        centroid += t.weights[i] * bandHz_[i];
    }

    const double kneeWidth = lerp(3.0, 6.5, musicality);
    const double knee = maxExcess / (maxExcess + kneeWidth);
    const double confidence = clamp(maxExcess / 16.0, 0.0, 1.0);

    t.grDb = clamp(params_.maxReductionDb * params_.amount * knee, 0.0, params_.maxReductionDb);
    t.activity = confidence;
    t.detectedHz = confidence > 0.015 ? centroid : 0.0;
    return t;
}

DeEsserDSP::Target DeEsserDSP::computeTarget(const ChannelState& st) const noexcept {
    return computeTarget(st.fullEnv, st.voiceEnv, st.bandEnv);
}

DeEsserDSP::Target DeEsserDSP::linkedTarget(std::size_t channels) const noexcept {
    std::array<double, kBands> bands{};
    double full = 0.0;
    double voice = 0.0;
    const std::size_t n = std::min(channels, channels_.size());
    if (n == 0) return {};
    for (std::size_t ch = 0; ch < n; ++ch) {
        full += channels_[ch].fullEnv;
        voice += channels_[ch].voiceEnv;
        for (std::size_t i = 0; i < kBands; ++i) bands[i] += channels_[ch].bandEnv[i];
    }
    const double inv = 1.0 / static_cast<double>(n);
    full *= inv;
    voice *= inv;
    for (auto& v : bands) v *= inv;
    return computeTarget(full, voice, bands);
}

template <typename Sample>
void DeEsserDSP::processImpl(const Sample* const* input, Sample* const* output,
                             std::size_t channels, std::size_t samples) noexcept {
    if (!input || !output || channels == 0 || samples == 0 || channels_.empty()) return;
    channels = std::min(channels, channels_.size());

    double blockInPeak = 0.0;
    double blockOutPeak = 0.0;
    double blockMaxGr = 0.0;
    double blockActivity = 0.0;
    double detectedNumerator = 0.0;
    double detectedDenominator = 0.0;

    const double music = params_.musicality;
    const double attackSeconds = lerp(0.00022, 0.00055, music);
    const double releaseBase = lerp(0.040, 0.145, music);
    const double attackCoeff = timeCoeff(sampleRate_, attackSeconds);
    const double weightCoeff = timeCoeff(sampleRate_, lerp(0.004, 0.018, music));
    const int hold = static_cast<int>(std::round(sampleRate_ * lerp(0.0005, 0.0040, music)));

    for (std::size_t n = 0; n < samples; ++n) {
        for (std::size_t ch = 0; ch < channels; ++ch) {
            const double x = sanitize(static_cast<double>(input[ch][n]));
            blockInPeak = std::max(blockInPeak, std::fabs(x));
            updateDetector(channels_[ch], x);
            auto& st = channels_[ch];
            if (!st.delay.empty()) st.delay[st.writePos] = x;
        }

        const Target linked = (params_.stereoLink && channels > 1) ? linkedTarget(channels) : Target{};

        for (std::size_t ch = 0; ch < channels; ++ch) {
            auto& st = channels_[ch];
            const Target target = (params_.stereoLink && channels > 1) ? linked : computeTarget(st);

            if (target.grDb > st.grDb) {
                st.grDb = attackCoeff * st.grDb + (1.0 - attackCoeff) * target.grDb;
                st.holdSamples = hold;
            } else if (st.holdSamples > 0) {
                --st.holdSamples;
            } else {
                const double strongEvent = clamp(st.grDb / std::max(1.0f, params_.maxReductionDb), 0.0, 1.0);
                const double releaseSeconds = releaseBase * (1.0 + 0.55 * strongEvent);
                const double releaseCoeff = timeCoeff(sampleRate_, releaseSeconds);
                st.grDb = releaseCoeff * st.grDb + (1.0 - releaseCoeff) * target.grDb;
            }

            for (std::size_t i = 0; i < kBands; ++i)
                st.weight[i] = weightCoeff * st.weight[i] + (1.0 - weightCoeff) * target.weights[i];

            if (target.detectedHz > 0.0) {
                const double freqCoeff = timeCoeff(sampleRate_, 0.020);
                if (st.detectedHz <= 0.0) st.detectedHz = target.detectedHz;
                else st.detectedHz = freqCoeff * st.detectedHz + (1.0 - freqCoeff) * target.detectedHz;
            } else if (target.activity < 0.01) {
                st.detectedHz = 0.0;
            }

            const std::size_t delaySize = st.delay.size();
            const std::size_t readPos = delaySize ? ((st.writePos + 1u) % delaySize) : 0u;
            const double dry = delaySize ? st.delay[readPos] : sanitize(static_cast<double>(input[ch][n]));

            double filtered[kBands]{};
            for (std::size_t i = 0; i < kBands; ++i) filtered[i] = st.processFilters[i].process(dry);

            double removed = 0.0;
            if (!params_.bypass && st.grDb > 1.0e-7) {
                const double removal = 1.0 - dbToGain(-st.grDb);
                for (std::size_t i = 0; i < kBands; ++i)
                    removed += removal * st.weight[i] * filtered[i];
            }

            double y = params_.listen ? removed : (dry - removed);
            if (params_.bypass) y = dry;
            y = sanitize(y);
            output[ch][n] = static_cast<Sample>(y);

            blockOutPeak = std::max(blockOutPeak, std::fabs(y));
            blockMaxGr = std::max(blockMaxGr, st.grDb);
            blockActivity = std::max(blockActivity, target.activity);
            if (st.detectedHz > 0.0 && target.activity > 0.0) {
                detectedNumerator += st.detectedHz * target.activity;
                detectedDenominator += target.activity;
            }

            if (delaySize) st.writePos = (st.writePos + 1u) % delaySize;
        }
    }

    const double decay = std::pow(meterDecayPerSample_, static_cast<double>(samples));
    meterInPeak_ = std::max(blockInPeak, meterInPeak_ * decay);
    meterOutPeak_ = std::max(blockOutPeak, meterOutPeak_ * decay);
    const double activityRelease = timeCoeff(sampleRate_, 0.080);
    meterActivity_ = std::max(blockActivity, meterActivity_ * std::pow(activityRelease, static_cast<double>(samples)));

    meters_.inputPeakDb = static_cast<float>(gainToDb(meterInPeak_));
    meters_.outputPeakDb = static_cast<float>(gainToDb(meterOutPeak_));
    meters_.gainReductionDb = static_cast<float>(clamp(blockMaxGr, 0.0, 18.0));
    meters_.detector = static_cast<float>(clamp(meterActivity_, 0.0, 1.0));
    meters_.detectedFrequencyHz = detectedDenominator > 1.0e-12
        ? static_cast<float>(clamp(detectedNumerator / detectedDenominator, 0.0, 12000.0))
        : 0.0f;
}

void DeEsserDSP::process(const float* const* input, float* const* output,
                         std::size_t channels, std::size_t samples) noexcept {
    processImpl(input, output, channels, samples);
}

void DeEsserDSP::process(const double* const* input, double* const* output,
                         std::size_t channels, std::size_t samples) noexcept {
    processImpl(input, output, channels, samples);
}

template void DeEsserDSP::processImpl<float>(const float* const*, float* const*, std::size_t, std::size_t) noexcept;
template void DeEsserDSP::processImpl<double>(const double* const*, double* const*, std::size_t, std::size_t) noexcept;

} // namespace deeser
